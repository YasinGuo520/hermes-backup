---
name: ai-video-production
description: AI视频生产全流程：本地流水线（moviepy+ffmpeg）与云端平台（小云雀/即梦/可灵），含工作流选型与短视频内容方案模板。
triggers:
  - AI视频生成
  - 自动视频
  - 视频合成
  - moviepy
  - edge-tts
  - TTS配音
  - 竖屏视频
  - Python视频
  - 文字转视频
  - 带货视频
related:
  - llm-video-maker  # 互补：HyperFrames 确定性动画出片
  - short-drama-pipeline  # 短剧管线
platforms: [macos, linux]
---

# AI Video Production（全自动AI视频生产流水线）

使用本地 Python 工具（moviepy + edge-tts + ffmpeg）从文案到成品 MP4 的端到端自动化流水线。**无需 GPU，无需云 API 调用**，全在本机运行。

**适用范围：** 抖音带货视频、AI工具测评、知识科普、产品介绍等竖屏短视频。

**双模式：** 本技能同时覆盖本地 Python 流水线（moviepy+edge-tts+ffmpeg：快速、低成本、可批量生产）与云端平台工作流（小云雀/即梦/可灵：高质量视觉素材）——见下文「云端视频平台工作流」章节。

---

## 流水线架构

```
┌──────────────────────────────────────────────────────┐
│               AI 视频生产流水线                         │
├──────────────────────────────────────────────────────┤
│                                                      │
│  Hermes (我)            工具             输出           │
│  ──────────────────────────────────────────────       │
│  ① 写文案 + 分镜        —              → 脚本文本     │
│  ② 生成幻灯片    →  moviepy.TextClip   → PNG帧        │
│  ③ 生成配音      →  edge-tts(Python)   → MP3语音      │
│  ④ 合成视频      →  moviepy + ffmpeg   → MP4成品      │
│                                                      │
└──────────────────────────────────────────────────────┘
```

---

## 前置依赖

```bash
# 必装
pip3 install moviepy pydub edge-tts numpy -i https://pypi.tuna.tsinghua.edu.cn/simple

# ffmpeg 需已安装（macOS 可 brew install ffmpeg）
which ffmpeg
```

**注意：** 用 `pip3` 而非 `pip`，确保与 `python3` 对应。如遇 `ModuleNotFoundError`，在脚本头加：
```python
import sys, site
sys.path.insert(0, site.getusersitepackages())
```

---

## 核心工作流

### 1. 文案 & 分镜设计

写脚本时按「镜头」划分，每个镜头指定：**时长 + 画面描述 + 配音文案**。

**分镜模板：**

| # | 时间 | 画面 | 文案 |
|---|------|------|------|
| 1 | 0-5s | 标题封面，大字标题+小字副标题 | (无/开场白) |
| 2 | 5-10s | 痛点画面，问题描述 | "你花3小时做XX？..." |
| 3 | 10-16s | 方案介绍，工具/产品展示 | "今天测评这个..." |
| 4 | 16-24s | 步骤说明，分步卡片 | "怎么用？三步..." |
| 5 | 24-30s | 对比/效果展示 | "以前...现在..." |
| 6 | 30-35s | 结果验证 | "关键是真的能落地..." |
| 7 | 35-45s | CTA关注 | "关注我，下期..." |

**文案要求：**
- 配音语速按 **260-280字/分钟** 估算
- 45秒视频 ≈ 180-220字
- 段落之间留自然停顿

### 2. 生成幻灯片（moviepy TextClip）

**重要：moviepy 2.x API 与 1.x 差异较大，以下为 2.x 正确用法。**

```python
from moviepy import VideoClip, TextClip, CompositeVideoClip

W, H = 720, 1280  # 竖屏 9:16

def solid_bg(color):
    """返回纯色帧函数 — frame_function 参数名！"""
    def make_frame(t):
        import numpy as np
        frame = np.zeros((H, W, 3), dtype=np.uint8)
        frame[:] = color
        return frame
    return make_frame

# 创建背景
bg = VideoClip(frame_function=solid_bg((18, 18, 30)), duration=5.0)

# 创建文字
title = TextClip(
    text="标题文字",
    font="/System/Library/Fonts/STHeiti Medium.ttc",  # macOS中文字体
    font_size=52,          # 720p 下 52pt 合适
    color="white",
    stroke_color="#6C63FF",
    stroke_width=1,
    size=(W - 120, None),  # 左右留边距
    method="caption",       # 2.x 用 caption 而非 label
    text_align="center",
).with_duration(5.0).with_position(("center", H // 2 - 80))

# 合成
composite = CompositeVideoClip([bg, title], size=(W, H))
```

**关键 API 差异（2.x vs 1.x）：**

| 概念 | 1.x | 2.x |
|------|-----|-----|
| 帧函数参数 | `make_frame` | `frame_function` |
| 帧返回值 | tuple `(0,0,0)` | numpy array `np.zeros((H,W,3))` |
| TextClip.text | `txt` 参数 | `text` 参数 |
| TextClip.method | `label`(默认) | `caption`(推荐，自动换行) |
| 设置时长 | 构造时传 | `.with_duration(n)` |
| 设置位置 | 构造时传 | `.with_position(x, y)` |
| 截取片段 | `.subclip(s, e)` | `.subclipped(s, e)` |
| 合并视频 | `concatenate_videoclips` | 同名但 method='compose' |
| 加音频 | `.set_audio(a)` | `.with_audio(a)` |

### 3. 生成配音（edge-tts）

```python
import edge_tts, asyncio

communicate = edge_tts.Communicate(
    "配音文本内容",
    voice="zh-CN-XiaoxiaoNeural",  # 中文女声，自然清晰
    rate="+15%",   # 语速加快15%（适配短视频节奏）
    pitch="+0Hz"
)
asyncio.run(communicate.save("/path/to/output.mp3"))
```

**推荐中文语音选项：**

| 语音 | 性别 | 风格 | 适合场景 |
|------|------|------|---------|
| `zh-CN-XiaoxiaoNeural` | 女 | 自然亲切 | **通用推荐** |
| `zh-CN-YunxiNeural` | 男 | 活力 | 测评/科技 |
| `zh-CN-YunjianNeural` | 男 | 专业 | 知识科普 |
| `zh-CN-XiaoyiNeural` | 女 | 活泼 | 带货/种草 |

### 4. 合成视频（带音频对齐）

```python
from moviepy import AudioFileClip

audio = AudioFileClip("voiceover.mp3")
video = concatenate_videoclips(slides, method="compose")

# 对齐时长
final_dur = min(video.duration, audio.duration)
video = video.subclipped(0, final_dur)
audio = audio.subclipped(0, final_dur)
video = video.with_audio(audio)

# 输出
video.write_videofile(
    "output.mp4",
    fps=24,
    codec="libx264",
    audio_codec="aac",
    preset="ultrafast",  # 无独显机器用 ultrafast
    bitrate="1500k",
    threads=4,
)
```

---

## 性能优化（Intel Mac 无独显）

| 优化项 | 建议值 | 效果 |
|--------|--------|------|
| 分辨率 | 720×1280（非1080p） | 帧数减少55% |
| 编码预设 | `ultrafast`（非 medium） | 速度提升3-5倍 |
| 码率 | 1500k（非 3000k） | 渲染更快，文件更小 |
| 帧率 | 24fps | 够用 |
| 线程数 | 4（i7 4核8线程） | 充分利用CPU |

**实测数据（MacBook i7-1068NG7）：**
- 1080p medium → ~1.1fps 渲染，~18分钟/50秒视频
- 720p ultrafast → ~2.7fps 渲染，~6.5分钟/50秒视频（包含语音生成时间）

---

## macOS 字体注意

| 字体路径 | 支持中文 | 说明 |
|---------|:-------:|------|
| `/System/Library/Fonts/STHeiti Medium.ttc` | ✅ | **推荐**，简化字，粗体适中 |
| `/System/Library/Fonts/PingFang.ttc` | ✅ | 但 PIL/ImageFont 可能报错 |
| `/Library/Fonts/Arial Unicode.ttf` | ✅ | 可用但字形较老 |
| `/System/Library/Fonts/Hiragino Sans GB.ttc` | ✅ | 细体，适合副标题 |

**PingFang.ttc 报错解决：** 如果报 `cannot open resource`，换用 `STHeiti Medium.ttc`。`.ttc` 是集合字体格式，PIL 不一定能打开所有索引。

---

### 字幕/副标题位置规则（用户偏好）

| 元素 | 位置 | 说明 |
|------|------|------|
| **主标题** | `(center, H//2 - 120)` | 居中偏上 |
| **副标题/解说文字** | `(center, H - 180)` | **底部**，不要放中间 |

### 程序化渐变背景（AI生图质量不足时的回退方案）

当用户反馈「图太low了」「没有科技感」时，**立即切换到此方案**，不要继续优化AI生图提示词。

```python
def gradient_bg(color_top, color_bot):
    def make_frame(t):
        import numpy as np
        frame = np.zeros((H, W, 3), dtype=np.uint8)
        for y in range(H):
            ratio = y / H
            frame[y, :] = [
                int(color_top[0]*(1-ratio) + color_bot[0]*ratio),
                int(color_top[1]*(1-ratio) + color_bot[1]*ratio),
                int(color_top[2]*(1-ratio) + color_bot[2]*ratio),
            ]
        return frame
    return make_frame
```

推荐配色（科技深色主题）：

| 场景 | 顶色(RGB) | 底色(RGB) | 风格 |
|------|-----------|-----------|------|
| 标题/开场 | (10,10,50) | (40,10,80) | 蓝紫科技 |
| 痛/警告 | (50,10,10) | (80,20,20) | 红强调 |
| 工具/产品 | (10,20,60) | (20,40,100) | 蓝光 |
| 步骤/教程 | (10,10,40) | (30,20,70) | 紫蓝 |
| 对比 | (40,10,10) | (10,40,10) | 红→绿 |
| 结果/肯定 | (10,30,20) | (20,60,40) | 绿科技 |
| CTA/关注 | (20,10,50) | (50,20,90) | 紫发光 |

### ⚠️ VideoFileClip + 淡入淡出不兼容

永远不要对包含 VideoFileClip 的 CompositeVideoClip 应用 FadeIn/FadeOut。会导致：
```
AttributeError: 'NoneType' object has no attribute 'get_frame'
```

原因：FadeIn/FadeOut 创建 mask 触发 clip 变换，VideoFileClip reader 在复合剪辑中被关闭。

正确做法有两个：

#### 方案A：硬切（最稳）

循环短视频做背景，直接拼接硬切：

```python
def make_slide(bg_clip, title_text, subtitle_text, duration):
    bg_dur = bg_clip.duration
    loops = max(1, math.ceil(duration / bg_dur))
    parts = [bg_clip] * loops
    bg_looped = concatenate_videoclips(parts, method="chain")
    bg_segment = bg_looped.subclipped(0, duration).resized((W, H))
    # ... 叠加文字 ...
    return CompositeVideoClip(clips, size=(W, H))
```

#### 方案B：交叉溶解 CrossFadeIn（推荐，平滑过渡）

**已验证可用。** `CrossFadeIn` 来自 `moviepy.video.fx`，与 VideoFileClip 兼容：

```python
from moviepy.video.fx import CrossFadeIn

slides = [...]  # 所有分镜已完成

OVERLAP = 0.3  # 重叠时长（秒）
composite_clips = []
current_t = 0.0
for i, s in enumerate(slides):
    if i > 0:
        # 第二帧开始加 CrossFadeIn 渐显
        s = s.with_effects([CrossFadeIn(OVERLAP)])
    composite_clips.append(s.with_start(current_t))
    current_t += s.duration - OVERLAP

video = CompositeVideoClip(composite_clips, size=(W, H))
video = video.with_duration(current_t + slides[-1].duration)
```

**原理：** 两帧重叠 OVERLAP 秒，上一帧渐隐的同时下一帧渐现。不经过黑屏，画面连续。

**注意事项：**
- `CrossFadeIn` 只影响叠加层中靠后的帧，前一帧（无 CrossFadeIn）维持原透明度
- 第一帧不加 CrossFadeIn（直接显示），最后一帧不特殊处理（自然结束）
- 最终视频总时长 = 所有分镜时长之和 - (分镜数-1) × OVERLAP
- 不要混合使用 FadeIn/FadeOut + CrossFadeIn — 两者生效机制冲突

### Wan2.2视频作为动态背景

流程：
1. 调SiliconFlow Wan2.2 T2V生成氛围视频（约5秒竖屏）
2. 循环该视频至所需总时长
3. 作为背景叠加文字和配音

详见 `references/wan-t2v-pipeline.md`

### 🧠 重要：先用 LLM 生成视频脚本/配音文案

**不要硬编码配音词。** 用户明确要求用 LLM 生成脚本。每次做带货视频前：

1. 根据品牌/产品/目标用户上下文，用 LLM 生成 3-4 句配音文案
2. 同步设计字幕时间轴（每句对应哪段画面、什么时候出现）
3. 让用户确认文案后再生成 TTS

**推荐长度：** 8-10秒视频≈3-4句，每句 8-15 字。edge-tts 语速 +10%~+15%。

## 百炼 I2V 图生视频管线（实拍产品 → AI动效）

当你有 **实拍产品照片** 需要做成动态视频时，走阿里百炼 DashScope API 做 I2V。
**优势：** 产品100%一致（实拍图），成本极低（¥0.06/条），5秒出片。市面上最便宜的图生视频方案。

### 前置条件

```bash
export DASHSCOPE_API_KEY="sk-xxx"
# bl CLI 需已安装（pip3 install bailian）
which bl
```

### 三步流程

#### 1️⃣ 上传产品图片到临时存储

```bash
bl file upload --file /path/to/product.jpg --model happyhorse-1.1-i2v --output json
```

返回 `{"url": "oss://dashscope-instant/...", "model": "happyhorse-1.1-i2v"}`。有效期 48 小时，`bl` CLI 自动处理 `X-DashScope-OssResourceResolve` header。

#### 2️⃣ 生成 I2V 视频（不同镜头变化产多条）

```bash
bl video generate \
  --model "happyhorse-1.1-i2v" \
  --image "oss://dashscope-instant/..." \
  --prompt "Slow push-in camera movement, model looking at camera, elegant commercial fashion, smooth cinematic motion" \
  --negative-prompt "Disfigured, deformed, blurry, low quality, distorted face" \
  --resolution "720P" \
  --ratio "9:16" \
  --duration 5 \
  --watermark false \
  --download /path/output.mp4 \
  --output json
```

**提示词示例（不同镜头变化）：**

| 镜头类型 | 提示词关键词 | 适合 |
|----------|-------------|------|
| 慢推进 | `Slow push-in camera, zoom in, product comes into focus` | 开场/产品特写 |
| 上移 | `Camera panning upward from waist to face` | 产品展示引导 |
| 转身 | `Model turns from side to face camera, hair flows naturally` | 多角度展示 |
| 环绕 | `Slow camera orbit around subject, 360 view` | 全方位展示 |

#### 3️⃣ 多条 I2V 片段 + 交叉淡化合成成片

```python
from moviepy import VideoFileClip, CompositeVideoClip, vfx

clips = [
    VideoFileClip("v2_pan_up.mp4").subclipped(0, 3),
    VideoFileClip("v3_turn.mp4").subclipped(0, 3),
    VideoFileClip("v1_push_in.mp4").subclipped(0, 3),
]

FADE = 0.5
layers = []
t = 0.0

for i, clip in enumerate(clips):
    if i == 0:
        c = clip.with_effects([vfx.FadeIn(FADE)])
        layers.append(c.with_start(t))
    elif i == len(clips) - 1:
        c = clip.with_effects([vfx.FadeIn(FADE), vfx.FadeOut(FADE)])
        layers.append(c.with_start(t - FADE))
    else:
        c = clip.with_effects([vfx.FadeIn(FADE), vfx.FadeOut(FADE)])
        layers.append(c.with_start(t - FADE))
    t += clip.duration

total_dur = sum(c.duration for c in clips) - FADE * (len(clips) - 1)
video = CompositeVideoClip(layers + text_clips, size=clips[0].size)
video = video.with_duration(total_dur).with_audio(voiceover_audio)
```

**原理：** 后一段 start 时间减去 FADE 秒重叠上一段，前一段淡出的同时后一段淡入，形成平滑交叉淡化。

### ⚠️ 成品画质警告：moviepy 合成后画质会下降

用 moviepy `CompositeVideoClip` + `write_videofile` 合成的视频画质**明显低于单条 I2V 源片**。原因：
- moviepy 每次合成都要重新编码全部帧（包括没变化的部分）
- `preset="ultrafast"` + `bitrate="1500k"` 压得不够，细节全丢
- **用户明确反馈过这个问题**（"成片的清晰度没有生成片段好"）

**补救方案：两段 ffmpeg 直出（保留画质）**

两段法：Pass 1 做交叉淡化，Pass 2 叠加字幕+配音。ffmpeg + CRF 18（视觉无损），不要用 moviepy 做最后合成。

#### Pass 1：ffmpeg xfade 交叉淡化

```python
import subprocess

DUR, FADE = 3.0, 0.5
W, H = 832, 1108
CLIPS = ["clip1.mp4", "clip2.mp4", "clip3.mp4"]

f1 = (
    f"[0:v]trim=0:{DUR},setpts=PTS-STARTPTS,scale={W}:{H}:"
    f"force_original_aspect_ratio=decrease,pad={W}:{H}:(ow-iw)/2:(oh-ih)/2,setsar=1[v0];"
    f"[1:v]trim=0:{DUR},setpts=PTS-STARTPTS,scale={W}:{H}:"
    f"force_original_aspect_ratio=decrease,pad={W}:{H}:(ow-iw)/2:(oh-ih)/2,setsar=1[v1];"
    f"[2:v]trim=0:{DUR},setpts=PTS-STARTPTS,scale={W}:{H}:"
    f"force_original_aspect_ratio=decrease,pad={W}:{H}:(ow-iw)/2:(oh-ih)/2,setsar=1[v2];"
    f"[v0][v1]xfade=transition=fade:duration={FADE}:offset=2.5[t1];"
    f"[t1][v2]xfade=transition=fade:duration={FADE}:offset=5.0[vout]"
)

subprocess.run([
    "ffmpeg", "-i", CLIPS[0], "-i", CLIPS[1], "-i", CLIPS[2],
    "-filter_complex", f1, "-map", "[vout]",
    "-c:v", "libx264", "-crf", "18", "-preset", "slow",
    "-pix_fmt", "yuv420p", "-r", "24", "-an", "-y", "temp_crossfade.mp4"
], check=True)
```

**参数说明：**
- `crf 18`：视觉无损（软件编码器恒定质量模式），成品比特率约 5000-6000kbps
- `preset slow`：压缩效率高，Intel Mac i7 渲染速度约 25fps（8秒视频≈8秒完成）
- `-an`：Pass 1 不要音频，Pass 2 再加

**xfade offset 计算公式（3段通用）：**
```python
CLIP_DUR = (VOICE_DUR + FADE * (NUM_CLIPS - 1)) / NUM_CLIPS
# xfade1: 第1→2段过渡，offset = CLIP_DUR - FADE
# xfade2: 第2→3段过渡，offset = CLIP_DUR * 2 - FADE * 2
# 例: CLIP_DUR=4.0, FADE=0.5 → xfade1_offset=3.5, xfade2_offset=7.0
```
确保 `CLIP_DUR * NUM_CLIPS - FADE * (NUM_CLIPS - 1) >= VOICE_DUR`。

#### Pass 2：PIL 字幕图 + ffmpeg overlay（避开 macOS ffmpeg 无 drawtext）

**macOS brew 安装的 ffmpeg 默认没有 `drawtext` 和 `subtitles` 滤镜。** 不要尝试用 `drawtext`，会报 `No such filter: 'drawtext'`。

正确做法：用 PIL 生成透明 PNG 字幕图 → ffmpeg `overlay` 叠加。

```python
from PIL import Image, ImageDraw, ImageFont

W, H = 832, 1108
FONT = "/System/Library/Fonts/STHeiti Medium.ttc"
FPS = 24
OUTPUT = "final_hq.mp4"

# 1. 生成字幕图（每段字幕区域一张透明PNG）
subs = [
    ("CHAOKE 潮客摄影", "专注内衣视觉定制", 0.0, 3.0),
    ("专业级光影质感", "每一帧都是大片", 3.0, 6.0),
    ("让您的品牌", "在镜头前惊艳绽放", 6.0, 8.5),
    ("您的品牌视觉合伙人", None, 8.5, 10.0),
]

import os
os.makedirs("_subs", exist_ok=True)
sub_files = []
for i, (l1, l2, start, end) in enumerate(subs):
    lines = [l for l in [l1, l2] if l]
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    y_base = int(H * 0.85)
    for j, line in enumerate(lines):
        fs = 34 if (j == 0 and "CHAOKE" in line) else (30 if j == 0 else 28)
        font = ImageFont.truetype(FONT, fs)
        bbox = draw.textbbox((0, 0), line, font=font)
        tw = bbox[2] - bbox[0]
        x, y = (W - tw) // 2, y_base + j * 40
        for dx, dy in [(-2,-2),(-2,2),(2,-2),(2,2),(0,-2),(0,2),(-2,0),(2,0)]:
            draw.text((x+dx, y+dy), line, font=font, fill=(0,0,0,200))
        draw.text((x, y), line, font=font, fill=(255,255,255,255))
    path = f"_subs/sub_{i}.png"
    img.save(path)
    sub_files.append({"path": path, "start": start, "end": end, "dur": end - start})

# 2. ffmpeg overlay 链：每张图用 -loop 1 -t <dur> 循环指定时长
import subprocess, json

inputs = ["ffmpeg", "-i", "temp_crossfade.mp4", "-i", "voiceover.mp3"]
for sf in sub_files:
    inputs.extend(["-loop", "1", "-t", str(sf["dur"]), "-i", sf["path"]])

# 构建 overlay 链（用 enable='between(t,start,end)' 控制显示时间）
prev = "0"
filter_parts = []
for i, sf in enumerate(sub_files):
    img_idx = i + 2
    src_ref = f"[{prev}:v]" if prev.isdigit() else f"[{prev}]"
    enable = f"between(t,{sf['start']},{sf['end']})"
    label = f"t{i+1}" if i < len(sub_files) - 1 else "vout"
    filter_parts.append(f"{src_ref}[{img_idx}:v]overlay=format=auto:enable='{enable}'[{label}]")
    prev = label

cmd = inputs + [
    "-filter_complex", ";".join(filter_parts),
    "-map", "[vout]", "-map", "1:a",
    "-c:v", "libx264", "-crf", "18", "-preset", "slow",
    "-c:a", "aac", "-b:a", "192k",
    "-pix_fmt", "yuv420p", "-r", str(FPS),
    "-shortest", "-y", OUTPUT,
]
subprocess.run(cmd, check=True)
```

**最终输出参数：** CRF 18 + preset slow ≈ 5500-5800kbps，画质接近源片。对比 moviepy ultrafast 2500kbps 提升明显。

#### 出画质对比

| 方案 | 编码预设 | 比特率 | 文件大小(8s) | 画质 |
|------|---------|--------|------------|------|
| moviepy ultrafast 2500k | ultrafast | ~2500kbps | 2.4MB | ❌ 细节丢失 |
| ffmpeg CRF18 slow | slow | ~5800kbps | 5.6MB | ✅ 接近源片 |

### ⚠️ 配音时长匹配视频长度（重要坑点）

**不要硬算视频时长。** 配音生成后才能知道确切长度。步骤：

1. 先生成配音 → edge-tts 出 MP3
2. 用 `ffprobe -v quiet -show_format voiceover.mp3 | grep duration` 测时长
3. 根据配音时长反推每段视频截取长度：
   - `clip_dur = (voice_dur + FADE * (NUM_CLIPS - 1)) / NUM_CLIPS`
   - 确保 `clip_dur * NUM_CLIPS - FADE * (NUM_CLIPS - 1) >= voice_dur`
4. 配音时长 > 视频时长 = 文案被吞。**这是用户最反感的低级错误。**

### 背景音乐生成（ffmpeg lavfi）

最终合成前用 ffmpeg 工具生成简单的环境音 BGM，不要空手出片。

生成3层 BGM（220Hz pad + 330Hz pad + 粉噪）：
```bash
ffmpeg -f lavfi -i "sine=frequency=220:duration=10,volume=0.15" \
  -f lavfi -i "sine=frequency=330:duration=10,volume=0.08" \
  -f lavfi -i "anoisesrc=d=10:c=pink:a=0.02" \
  -filter_complex "[0:a][1:a][2:a]amix=inputs=3:duration=first[BGM]" \
  -map "[BGM]" -y bgm.mp3
```

混音：BGM 25% + 配音 100% + 300ms 延时起步（不压人声）：
```bash
ffmpeg -i bgm.mp3 -i voiceover.mp3 \
  -filter_complex \
  "[0:a]volume=0.3[bg];[1:a]adelay=300|300[voice];[bg][voice]amix=inputs=2:duration=first:weights=0.25 1[out]" \
  -map "[out]" -y mixed.mp3
```

**费用参考**

| 项目 | 费用 |
|------|------|
| bl I2V (happyhorse-1.1-i2v) | **¥0.06/条** |
| bl file upload | ¥0 |
| edge-tts 配音 | ¥0 |
| SiliconFlow Wan2.2-I2V（对比） | $0.21-0.29/条 ≈¥1.5-2.1 |

**并发生成多条 I2V（推荐）：** 百炼单条生成约 30-60 秒，顺序跑3条要3分钟。
后台并行跑（`&` + `wait`）压缩到1分钟：
```bash
bl video generate --model happyhorse-1.1-i2v --image "oss://..." \
  --prompt "Slow push-in camera, elegant commercial fashion" \
  --resolution "720P" --ratio "9:16" --duration 5 --watermark false \
  --download clip1.mp4 --output json &
bl video generate --model happyhorse-1.1-i2v --image "oss://..." \
  --prompt "Camera panning upward from waist to face" \
  --download clip2.mp4 --output json &
bl video generate --model happyhorse-1.1-i2v --image "oss://..." \
  --prompt "Model turns from side to face camera, hair flows naturally" \
  --download clip3.mp4 --output json &
wait
echo "全部生成完成"
```

### 核心原则：产品必须实拍，不要 AI 生

**不要用 AI 生成产品图再转视频。** AI 生图的产品细节（标签文字、包装颜色、logo）必跑偏，带货挂小黄车退货率炸。

正确管线：
```
实拍产品照 → bl upload → bl video generate（多条不同镜头）
→ moviepy 合成 + 配音 + 字幕 → 带货视频成品
```

详见 `references/bailian-i2v-session.md` 和 `references/jianying-capcut-compatibility.md`。

### 百炼 I2V 补充坑（合并自 chaoke-i2v-product-video）
- **并行生成中断 `exit 130`**：`bl video generate` 是同步阻塞调用，并行跑2条以上时第二条被中断。**逐条串行生成**，每次等前一条完成再跑下一条（单条约60-90秒）。
- **用户问"为什么走百炼不是硅基"**：生成前先告知「视频生成走百炼 DashScope ¥0.06/条，不是硅基」。硅基（SiliconFlow）没有 happyhorse 模型，其 Wan2.2-I2V-A14B 要 $0.29/条（≈¥2.1）。
- **账单查询限制**：`bl usage stats` 需要 console login，查余额/欠费去百炼控制台 https://bailian.console.aliyun.com（后付费，欠费仍返回200但费用累积）。详细账单对比见 `references/bailian-billing.md`。
- 完整可运行合成脚本：`scripts/build_final.py`（修改配音+字幕配置后直接 `python3 build_final.py` 出片）。
- 出片参数：832×1108 / 24fps / H.264 CRF18 / preset slow / AAC 192k / 总成本 ¥0.18（3条I2V）。

### Wan2.2 背景补充（合并自 ai-video-full-pipeline）
- **淡入淡出不要用 FadeIn/FadeOut**（与 VideoFileClip 兼容问题 `NoneType get_frame`）。除 CrossFadeIn 外，另一可行法：手动创建黑帧遮罩叠加（`np.full((H,W,3), 255*alpha)` 的 VideoClip 叠在 composite 上）。
- Wan2.2 T2V 提交 `POST https://api.siliconflow.cn/v1/video/submit`（参数名是 `image_size` 不是 size），轮询 `POST .../v1/video/status`（POST 不是 GET，`{"requestId": ...}`），状态 InQueue→InProgress→Succeed/Failed，10s 间隔最长10分钟，生成约8-9分钟（排队+推理）。
- 已知限制：Wan2.2 目前只能生成氛围画面（科技感动态背景），无法生成带具体角色/叙事逻辑的内容视频。

## 🚀 执行清单 Cheat Sheet（一条接一条）

从拿到产品图到出片，按顺序执行：

### 步骤1：生成配音文案（LLM）
```
当前模型生成 3-4 句脚本 → 让用户确认 → edge-tts 出 MP3
```

### 步骤2：上传产品图 → 生成3条I2V动态
```bash
# 上传图片
bl file upload --file product.jpg --model happyhorse-1.1-i2v --output json
# 记住返回的 oss://... URL

# 并发生成3条不同镜头（并行执行不排队）
bl video generate --model happyhorse-1.1-i2v --image "oss://..." \
  --prompt "Slow push-in camera, elegant commercial fashion" \
  --negative-prompt "Disfigured, deformed, blurry" \
  --resolution "720P" --ratio "9:16" --duration 5 --watermark false \
  --download clip1.mp4 --output json &

bl video generate --model happyhorse-1.1-i2v --image "oss://..." \
  --prompt "Camera panning upward from waist to face" \
  ... --download clip2.mp4 &

bl video generate --model happyhorse-1.1-i2v --image "oss://..." \
  --prompt "Model turns from side to face camera" \
  ... --download clip3.mp4 &

wait  # 等全部完成
```

### 步骤3：测配音时长
```bash
ffprobe -v quiet -show_format voiceover.mp3 | grep duration
# → duration=9.936000
```

### 步骤4：根据配音时长计算每段截取长度
```python
VOICE_DUR = 9.94  # 上一步测出
FADE = 0.5
NUM_CLIPS = 3
# clip_dur * 3 - FADE * 2 >= VOICE_DUR
CLIP_DUR = (VOICE_DUR + FADE * (NUM_CLIPS - 1)) / NUM_CLIPS
# → 约 3.65 秒/段
```

### 步骤5：Pass 1 — ffmpeg xfade 交叉淡化
```bash
# xfade offset 公式：
# xfade1_offset = CLIP_DUR - FADE
# xfade2_offset = CLIP_DUR * 2 - FADE * 2
# 3段 = 2个xfade
```

参考上节「Pass 1：ffmpeg xfade 交叉淡化」完整命令。

### 步骤6：Pass 2 — PIL字幕图 + ffmpeg overlay + BGM + 配音混音

参考上节「Pass 2」「背景音乐生成」「配音时长匹配」三段内容合成最终视频。

## 常见坑点

| 问题 | 原因 | 解决 |
|------|------|------|
| `ModuleNotFoundError: No module named 'moviepy'` | Python 路径问题 | 脚本头加 `sys.path.insert(0, site.getusersitepackages())` |
| `tuple' object has no attribute 'shape'` | frame 函数返回了 tuple 而非 numpy array | 返回 `np.zeros((H,W,3), dtype=np.uint8)` |
| `Invalid font ... cannot open resource` | PIL 无法打开 .ttc 字体 | 换用 `STHeiti Medium.ttc` |
| `end_time should be smaller or equal to the clip's duration` | audio/video 时长差太小 | 用 `min(dur1, dur2)` 统一裁剪 |
| TTS 无输出/报错 | edge-tts 网络问题 | 重试，或检查 `voice` 参数名 |
| `No such filter: 'drawtext'` | macOS brew ffmpeg 默认不含 drawtext 滤镜 | 不要尝试用 drawtext。改走 PIL 生成字幕 PNG + ffmpeg overlay 叠加 | | 1080p + medium preset | 降为 720p + ultrafast |
| background 进程报 `ModuleNotFoundError` | 后台进程 PYTHONPATH 不同 | 用 foreground 终端执行 |
| 视频突然出声 | Camofox 自动播放 | 打 firefoxUserPrefs 静音补丁（见 hermes-china-setup） |

---

## 剪映/CapCut 渲染备选（jianying-editor-skill）

### ⚠️ 版本兼容性：只支持 ≤5.9 ⚠️

**剪映 10.x+ 已加密 draft_info.json（纯二进制），整个 skill 完全不可用。** 必须用 5.9 或更低版本。详见 `references/jianying-capcut-compatibility.md`。

当用户有 **剪映专业版 5.9** 时，可以用 [jianying-editor-skill](https://github.com/luoluoluo22/jianying-editor-skill) 替代 ffmpeg 做最终合成。优势：
- 剪映原生特效、字幕动画、转场库（比 ffmpeg xfade 丰富得多）
- 内置云端音乐库
- 可视化编辑（出问题可以手动调）

劣势：
- 依赖剪映 5.9 或更低版本的自动导出（CapCut 国际版兼容性需测试）
- 草稿文件 API 不允许重叠片段（需手动写 transition 而不是依赖时间轴重叠）
- macOS 路径：自动检测 `~/Movies/JianyingPro Drafts/`，可手工指定

接入方式：
```python
from jy_wrapper import JyProject
proj = JyProject(project_name="my_draft", width=832, height=1108, overwrite=True)
proj.add_media_safe(video_path, start_time="0s", duration="3s", track_name="VideoTrack")
proj.add_text_simple("品牌名", start_time="0.5s", duration="2.5s", anim_in="淡入")
proj.save()  # 打开剪映即可看到草稿
```

适用于需要花字动画、专业转场、特效的高级场景。快速出片仍用 ffmpeg 两段法。

参考 `templates/i2v-product-video-build.py`（参数化脚本，改 PRODUCT_IMAGE 和 TTS_TEXT 直接跑）和 `references/build-script-template.md` 获取可复用的完整 Python 脚本模板。

使用方法：
1. 复制模板
2. 修改 `TTS_TEXT`（配音文案）
3. 修改 `SCENES`（分镜配置）
4. 运行 `python3 build_video.py`

---

## 云端视频平台工作流（合并自 ai-video-content-creation）

当走**云端 AI 视频平台**（小云雀/即梦AI/可灵AI）生成短视频素材时，完整流程（分镜规划 → 提示词编写 → 分段生成 → 合成配乐 → 与 Hermes 配合的 3 种模式）见 `references/cloud-platform-workflow.md`。

- **平台速查**：小云雀（xyq.jianying.com，注册1200积分+每天120）一句话出片零门槛；即梦AI（jimeng.jianying.com，Seedance）质量顶级、科幻场景最佳；可灵AI（klingai.com）物理理解强、广告级质量。无 GPU 环境全走云端。
- **核心原则**：一个镜头只放一个视觉元素+一个运动；15秒视频拆 5 个 3 秒片段；提示词指定运动方向（"从左向右飞入"）+ 氛围词（电影级布光/暖橙蓝对比）。
- **合成**：ffmpeg concat `-c copy` 合并 + BGM 淡入淡出。
- **火山方舟/Seedance API 程序化调用**（Key 类型是最大坑、计费表、验证命令）：`references/volcengine-ark-api.md`；独立知识库另见 `china-ai-platforms` skill（火山/硅基/百炼三平台选型总纲）。
- 平台对比与提示词模板库：`references/platform-comparison.md` / `references/video-platform-comparison.md` / `references/mars-base-prompts.md` / `references/siliconflow-video-api.md` / `references/text-to-video-pipeline.md`。

## 工作流编排与选型（合并自 video-production-workflow）

用户说「做个视频 / 出个片 / 做个带货视频」时按此决策：

```
用户给产品/主题/方向
  ├─ 短剧/剧情类 → short-drama-pipeline（含百炼出图+成片）
  ├─ 带货/种草/测评 → LLM-video-maker (HyperFrames)
  └─ 应急/兜底 → 本 skill 旧管线 (Wan2.2+moviepy)
```

**带货短视频标准流程：**
1. **VC 出文案**（不要手工写，VC 有爆款拆解能力）：`python3 ~/Desktop/hermes/viral_copywriter.py --mode A --product "<产品名>" --category "<品类>" --target "<目标人群>" --price <价格> --platform douyin`（或 alias `vc`）。
2. **转 HyperFrames 出片**：VC 文案整理成 `brief.json` → `npx hyperframes init projects/<id>` → 写 HTML/GSAP 构图（文案分段/动画/转场）→ `npx hyperframes render` → edge-tts 配音（+15%）→ ffmpeg 音画合成。详见下文「HyperFrames 确定性渲染」章节。
3. **交付**：成片存 `~/Desktop/hermes/video-maker/projects/<id>/renders/`；改文案重跑 VC，改画面调 HTML/GSAP 重渲染。

**要点：**
- 12 款视频工具按场景/平台/成本选型速查：`references/video-tools-catalog.md`。
- Manim 程序化动画（像素画/几何/数学确定性动画）：见下文「Manim 创意动画场景」章节（环境 `~/Desktop/hermes/manim-venv`，v0.20.1）。
- 带货视频字幕放**底部**（H-180）；转场必须**淡入淡出**不要硬切。

## 短视频内容方案模板库（合并自 xiaohuangben-video-creator）

输入「产品/行业 + 内容类型 + 子类型」→ 自动出完整视频方案（选题+脚本+分镜+AI管线+成本）的**内容策划引擎**，完整 12 模板见 `references/xiaohuangben-video-templates.md`。要点：

- **解析规则**：`[行业/产品] + [内容类型: 晒过程/教知识/聊观点/讲故事] + [子类型]`，内容类型缺省=晒过程（带货最常用）
- **8大爆款元素**（成本的/人群的/奇葩的/最差的/反差的/怀旧的/荷尔蒙的/头牌的）× **6个钩子技巧**（[金钱][验证/揭秘][盲盒][对抗][送温暖][荷尔蒙]）
- **输出7区块**：选题定位/脚本文案/分镜脚本/AI管线选择/风险预警/下一步行动/扩展选题灵感
- **管线映射**：晒过程→Seedance(火山方舟) 首选、Ken Burns 降级、百炼 I2V 兜底；教知识/聊观点→本 skill 文字视频；讲故事→llm-video-maker
- **文案字数**：10s≈40字 / 12s≈50字 / 15s≈60字 / 20s≈85字（260字/分钟）
- **执行铁律**：用户给图先做3件事（查水印/查HEIF格式/判断模特实拍）；先出配音再算视频长度；产品A/B对应关系必须用 vision_analyze 确认

---

## HyperFrames 确定性渲染（合并自 llm-video-maker）

**触发**：带货/种草/测评/产品宣传类短视频，需要 100% 确定性画面（文字不飘、数据准确）时用 HyperFrames（HTML/GSAP 代码驱动 → Chrome headless 渲染 MP4）。与 moviepy 管线互补：moviepy 快糙猛，HyperFrames 精致可控。

**工作流**：
1. 写 brief JSON（必需字段：`id`、`platform`(tiktok/reels/shorts/youtube/square)、`story`、`source`）→ `npx hyperframes init projects/<id>`（墙内 clone GitHub 超时就 Ctrl+C，脚手架已生成）
2. 读 brief → facts.json（画面事实必须可溯源）→ design.md（配色/字体/动效）→ storyboard.json → assets/ → index.html（HTML/GSAP 构图）
3. 校验：`npx hyperframes lint` + `npx hyperframes validate`（WCAG AA 对比度，最多3轮）
4. 渲染：`npx hyperframes render projects/<id> -o projects/<id>/renders/<id>.mp4`（draft 档快速迭代）
5. 音画合成：HyperFrames 默认无音频 → edge-tts 配音（中文用 Xiaoxiao +15%）+ ffmpeg amix 混音（weights=0.3 1，adelay 500ms）

**环境**：项目根 `~/Desktop/hermes/video-maker/`；Kokoro TTS venv 需 `export PATH="/Users/mac/.video-maker/runtime/python/bin:$PATH"`；Chromium 下载挂起时设 `PUPPETEER_DOWNLOAD_BASE_URL=https://npmmirror.com/mirrors/chromium-browser-snapshots/`。

**AI 关键帧**：产品/时尚素材用百炼 `bl image generate --model qwen-image-2.0-pro --size 9:16 --seed <N> --watermark false` 生成静态关键帧 + Ken Burns 慢推（GSAP `tl.fromTo()`，避免 CSS transform 冲突 lint 错）；NSFW 提示词会被拒，保持产品向措辞（"精致蕾丝内衣"而非"暴露"）。

**核心坑**：
- GSAP `repeat: -1` 破坏确定性 capture → 用有限 repeat（`Math.floor(remaining/cycle)-1`）
- 竖屏必须 `data-width="1080" data-height="1920"`（根 div + viewport meta 两处）
- `backdrop-filter` 触发慢速截图渲染（30s 视频 30s→3min+）→ 用 rgba 半透明层/渐变替代
- `hyperframes init` 墙内 clone 超时 → Ctrl+C 继续
- 章节级编辑（edit-video）：clock/narration/caption 三层锁定，只重写目标章 scenes 后整片重渲；project/chapter ID 匹配 `^[a-z0-9][a-z0-9-]*$` 防路径穿越
- Pexels 实拍背景：4K 需降到 1080×1920 + 30fps

**支持文件**：脚本 `scripts/validate-brief.mjs`/`plan-scenes.mjs`/`fetch-assets.mjs`/`analyze-codebase.mjs`/`capture-demo.mjs`/`normalize-transcript.mjs`（`node "$SKILL_DIR/scripts/<name>.mjs"`）+ `scripts/llm-video-maker-schema.json`；参考 `references/hyperframes-composition-template.md`（竖屏构图）、`references/hyperframes-product-video-template.md`（30s 产品片6镜头）、`references/pexels-stock-video-sourcing.md`（免费实拍）、`references/hyperframes-audio-post-processing.md`（配音合成）、`references/llm-video-install-notes.md`。

## Remotion 数据/文字视频（合并自 remotion-video-production）

**触发**：需要**精确文字/真实数据**的视频（AI 生视频会写错字）——量化 Top8 榜单、数据复盘、排行榜、网页动效转视频。0 成本本地渲染，与 AI 生视频互补：AI 出画面，Remotion 出数据与文字。

**环境**：项目 `~/Desktop/hermes/remotion-lab/`（remotion + @remotion/cli + react）；2核机 `remotion.config.ts` 里 `Config.setConcurrency(2)`（超核数报错）；chrome-headless-shell 在 `node_modules/.remotion/`。

**工作流**：写组件（index.tsx registerRoot → Root.tsx Composition 注册分辨率/时长/fps → 主组件）→ **先单帧预览** `npx remotion still src/index.tsx <CompId> out/preview.png --frame=180` → vision_analyze 检查布局/溢出/配色 → 全片渲染 `npx remotion render`（后台+notify_on_complete，300帧@1080x1920 约3分钟/1.8MB）→ ffprobe 验证。

**必备配置**：`tsconfig.json`（缺失报 "Could not find a tsconfig.json"）+ `remotion.config.ts`（`setVideoImageFormat("jpeg")`/`setOverwriteOutput(true)`/`setConcurrency(2)`）。

**常用动画**：粒子背景（useMemo+固定种子防每帧重生成抖动，frame 驱动 sin/cos 漂移）、行渐入（spring + stagger delay）、数字滚动（interpolate + clamp + `fontVariantNumeric:"tabular-nums"` 防宽度跳动）、渐变紫标题（WebkitBackgroundClip:text）。

**A股配色铁律**：红涨 `#ef4444` 绿跌 `#22c55e`；数据视频底部加权重 + "信号仅供研究"声明；改 Root.tsx 宽高/时长后需重新 bundle。

**支持文件**：`templates/remotion-data-showcase.tsx`（通用数据榜单组件，改 STOCKS 数组即出新片）、`references/remotion-quant-top8-example.md`（粒子+玻璃卡片+逐行弹入+分歧度三色完整实例）。

## Manim 创意动画场景（合并自 manim-creative-scenes）

**触发**：像素画逐格点亮、作品/角色画廊巡游、海报动态化等**非数学**创意展示动画（数学/算法解释视频见 bundled `manim-video`）。环境：`~/Desktop/hermes/manim-venv`（manim v0.20.1）。

**核心模式**：
- 像素矩阵逐格点亮：`LaggedStart(*[GrowFromCenter(sq) for sq in cells], lag_ratio=0.012)` 一次搞定，不要逐格 play
- 多作品共用一个 Scene 基类 + `type()` 动态生成（10 作品 = 10 行代码）
- 画廊节奏：金框+画布 Create → 标题 Write（画框下方，博物馆标签式）→ 逐格点亮 → 轻微浮动 → 淡出

**实战坑（全部验证）**：
1. **画幅裁剪（最坑）**：mobject 超出默认 14.22×8 画幅被直接裁掉 → `self.camera.frame_width/height` 调大（保持16:9）；或缩小元素（canvas 7.6/frame 8.4/cell 0.42 是安全组合）
2. **`-s` 预览黑帧**：结尾 FadeOut 全清 → 预览图纯黑，视觉模型误判失败 → 用 `manim -ql --format mp4` + ffmpeg 抽中间帧
3. **中文字体**：`fc-list :lang=zh` 确认 + 显式 `font=`（服务器 WenQuanYi Zen Hei）
4. 系统依赖：`apt install pkg-config libcairo2-dev libpango1.0-dev libffi-dev` 后再 pip 装 manim
5. 中文 Scene 类名出片名含中文 → cp 成英文名再给前端

**页面集成**：每作品 11s 720p mp4 仅 180-300KB 网页直接播；卡片缩略图抽动画中间帧（`-ss 7`）；点击卡片深色遮罩弹窗 + `<video controls autoplay loop>`。

**支持文件**：`references/manim-pixel-art-scenes.md`（完整可跑脚本模板 + 10作品动态类生成 + 踩坑详录）。



