---
name: china-ai-services
description: Configure Hermes with AI services accessible from restricted network environments (China) — web search, image generation, vision, and LLM backends that work without VPN.
tags: [china, network, setup, siliconflow, firecrawl, configuration, image-gen, vision, camofox, browser]
trigger: User is in China / restricted network and needs to configure web search, image generation, vision analysis, browser automation (Camofox/Camoufox), or any AI service API. User reports services being blocked, slow, or region-locked.
---

# China AI Services Configuration

Guide for configuring Hermes Agent with AI services accessible from mainland China without VPN. Covers working services, blocked services, and workarounds.

---

## Working Services (No VPN Needed)

### 1. Web Search & Extract: Firecrawl

Firecrawl is the default web backend and works well from China.

```bash
# 1. Get free API key at https://firecrawl.dev (500 credits/mo)
# 2. Save key
hermes config set web.backend firecrawl
echo 'FIRECRAWL_API_KEY=fc-xxxxx' >> ~/.hermes/.env
# 3. Restart gateway
hermes gateway restart
```

Provides both `web_search` and `web_extract`. 500 free credits/month.

### 2. Image Generation + Vision: SiliconFlow (硅基流动)

**硅基流动** (https://siliconflow.cn) is a Chinese AI platform providing OpenAI-compatible API for both image generation and vision — no VPN needed.

#### Registration
1. Open https://siliconflow.cn
2. Register with phone/email
3. Go to Console → API Keys → Create a new key
4. Free trial credits on signup; top up ¥10+ for continued use

#### Image Generation Configuration

```bash
# Save API key
echo 'SILICONFLOW_API_KEY=sk-xxxxx' >> ~/.hermes/.env
echo 'OPENAI_API_KEY=sk-xxxxx' >> ~/.hermes/.env   # needed by image_gen tool

# Configure Hermes
hermes config set image_gen.provider openai
hermes config set image_gen.base_url "https://api.siliconflow.cn/v1"
hermes config set image_gen.model "Qwen/Qwen-Image"
```

**Note:** The built-in `image_generate` tool with `provider=openai` may not properly route to SiliconFlow's image endpoint. Direct API call is more reliable:

```bash
# Direct API call (works reliably)
curl -s -X POST "https://api.siliconflow.cn/v1/images/generations" \
  -H "Authorization: Bearer $SILICONFLOW_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"Qwen/Qwen-Image","prompt":"...","n":1,"size":"1024x1024"}'
```

Available image models on SiliconFlow:
- `Qwen/Qwen-Image` — recommended, general purpose
- `Tongyi-MAI/Z-Image-Turbo` — faster
- `baidu/ERNIE-Image-Turbo` — Baidu's model
- `Kwai-Kolors/Kolors` — Kuaishou's model

#### Vision / Image Analysis Configuration

The built-in `vision_analyze` tool can be configured to work with SiliconFlow by setting the auxiliary vision model:

```bash
# Configure auxiliary vision provider to use SiliconFlow
hermes config set auxiliary.vision.provider openai
hermes config set auxiliary.vision.base_url "https://api.siliconflow.cn/v1"
hermes config set auxiliary.vision.model "Qwen/Qwen3-VL-32B-Instruct"

# The OPENAI_API_KEY env var (which points to SiliconFlow) is auto-detected
```

**Available vision models on SiliconFlow (verified working):**
| Model | Status | Notes |
|-------|--------|-------|
| `Qwen/Qwen3-VL-32B-Instruct` | ✅ Works | General vision, OCR, images |
| `Qwen/Qwen3-VL-8B-Instruct` | ✅ Works | Faster, lighter |
| `Qwen/Qwen3-VL-32B-Thinking` | ✅ Works | Slower but better reasoning |
| `Qwen/Qwen2.5-VL-72B-Instruct` | ❌ Disabled | Returns 403 "Model disabled" |
| `deepseek-ai/deepseek-vl2` | ❌ Disabled | Returns 403 "Model disabled" |
| `GLM-4.5V` series | ❓ Untested | Available on platform |

**Critical troubleshooting notes:**
- Config changes take effect on `/reset` (new session). The `vision_analyze` tool in the current session ignores mid-session config changes and may keep failing with the old model.
- The error `"This model is not available in your region"` means the vision provider/model combo is region-locked. Fix by switching to SiliconFlow as provider.
- The error `"Model disabled"` (code 30003) means the model ID is no longer active on SiliconFlow — try a different model ID.
- The error `"Model does not exist"` (code 20012) means the model ID string is wrong — check exact formatting at the platform.
- `GLM-4.5V` series is also available on SiliconFlow as an alternative if Qwen VL models are down.

**Fallback: direct Python call** (if the built-in tool still fails):

```python
import urllib.request, json, base64

with open("image.jpg", "rb") as f:
    b64 = base64.b64encode(f.read()).decode()

req = urllib.request.Request(
    "https://api.siliconflow.cn/v1/chat/completions",
    data=json.dumps({
        "model": "Qwen/Qwen3-VL-32B-Instruct",
        "messages": [{
            "role": "user",
            "content": [
                {"type": "text", "text": "描述这张图片"},
                {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}}
            ]
        }],
        "max_tokens": 500
    }).encode(),
    headers={
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
)
resp = json.loads(urllib.request.urlopen(req, timeout=60).read())
print(resp["choices"][0]["message"]["content"])
```

### 3. DeepSeek API

DeepSeek's API (https://api.deepseek.com) works from China. Already configured as the main LLM provider.

### 4. HuggingFace Models via Mirror

HuggingFace main site is blocked/times out. Use the mirror:
```bash
export HF_ENDPOINT=https://hf-mirror.com
# Then normal huggingface_hub / diffusers operations work
```

---

## Blocked / Limited Services (Need VPN or Alternative)

| Service | Issue | Alternative |
|---------|-------|-------------|
| Docker Desktop | Download CDN blocked, timeout | Aliyun mirror, or skip |
| Google Gemini Image models | 403 region block | SiliconFlow Qwen-Image |
| OpenAI Image (direct) | 403 region block | SiliconFlow / OpenRouter |
| OpenRouter free image models | 403 region block or payment needed | SiliconFlow |
| FAL.ai | Accessible but slow; registration may need VPN | SiliconFlow |
| HuggingFace (direct) | Timed out | hf-mirror.com |

### OpenRouter Partial Workaround

OpenRouter's website (`openrouter.ai`) IS accessible from China. You can:
- Register and get an API key (works)
- Use it for LLM chat (works)
- Use OpenAI image models if manually enabled in Settings
- Google Gemini image models are still region-blocked

API key format: `sk-or-v1-xxxxx`

---

## Local Image Generation on Intel Mac (Not Recommended)

Attempting local Stable Diffusion via `diffusers` on an Intel Mac (i7, no GPU, 16GB RAM):

| Issue | Details |
|-------|---------|
| CPU only | Intel Iris Plus Graphics, no GPU acceleration |
| PyTorch 2.2.2 | Too old for modern diffusers; `torch.xpu` attribute missing |
| Disk space | Model weights 1-7GB, only 31GB free |
| Speed | 30-60+ seconds per image on CPU |
| Dependencies | Multiple version conflicts between torch, diffusers, transformers |

**Conclusion:** Not worth pursuing. Use SiliconFlow API instead.

---

## Installing Third-Party Hermes Projects from GitHub in China

Cloning GitHub repos from China can be slow or timeout (especially large repos). The following workflow handles git clone, venv setup (macOS PEP 668), and integrating skills/plugins into Hermes.

### GitHub Clone Workaround

```bash
# Direct clone may timeout — use a mirror:
git clone https://ghproxy.net/https://github.com/user/repo.git

# Alternative mirrors (if one fails, try another):
#   ghproxy.net
#   ghproxy.cn  (SSL cert issue on some hosts)
#   gitclone.com/github.com/user/repo
```

### jsDelivr CDN — pull individual files without cloning

For fetching specific files (SKILL.md, scripts, configs) without cloning the full repo, jsDelivr CDN is the fastest option from China — it's hosted on mainland CDN nodes:

```bash
# Format:
# https://cdn.jsdelivr.net/gh/{owner}/{repo}@{tag}/{path}

# Example: pull a single raw file from GitHub
curl -sL "https://cdn.jsdelivr.net/gh/GoldLegendW80/llm-video-maker@main/skills/make-video/SKILL.md" \
  -o ~/.hermes/skills/my-skill/SKILL.md

# Pull scripts
curl -sL "https://cdn.jsdelivr.net/gh/user/repo@main/scripts/tool.mjs" \
  -o ~/.hermes/skills/my-skill/scripts/tool.mjs

# Pull schema or config files
curl -sL "https://cdn.jsdelivr.net/gh/user/repo@main/schema.json" \
  -o ~/.hermes/skills/my-skill/schema.json
```

**Advantages over git clone mirrors:**
- Much faster — pulls exactly the files you need, not the whole repo
- jsDelivr CDN nodes are in mainland China — no GFW throttling
- Works for individual files without any Git operations
- No partial clone / timeout issues — each file download is independent

**Limitations:**
- Only works for individual raw files from public repos (not entire repo clones)
- The repo must have a git tag or branch to reference (default: `@main` or `@master`)

### Downloading GitHub Release Assets (curl + ghproxy + resume)

When downloading individual release files (`.zip`, `.app`, `.dmg`, binaries) from
GitHub releases, `git clone` won't help — use `curl` through a GitHub mirror with
**resume support** for slow/spotty connections:

```bash
# 1. Test mirror first (HEAD request)
curl -sI "https://ghproxy.net/https://github.com/user/repo/releases/download/v1.0/file.zip" \
  --connect-timeout 10 --max-time 20 | grep -i "HTTP/"

# 2. Download with resume support
curl -L -C - -o ~/Desktop/hermes/file.zip \
  "https://ghproxy.net/https://github.com/user/repo/releases/download/v1.0/file.zip" \
  --connect-timeout 30 --max-time 300 --speed-time 30 --speed-limit 500 2>&1

# 3. If it times out (exit 28), just re-run the SAME command
#    -C - picks up where it left off automatically

# Key parameters for slow China connections:
#   -C -            resume partial download if interrupted (critical!)
#   --speed-time    seconds of below-speed before abort (30s)
#   --speed-limit   bytes/sec threshold (500 = ~0.5KB/s minimum)
#   --max-time      total wall-clock allowed (300s = 5 min)
```

**Pitfalls:**
- **ghproxy.net works for HEAD but stalls on large files** — use `--speed-time`
  and `--speed-limit` to avoid hanging forever on stalled connections.
- **Partial files are saved** when curl exits with code 28 (timeout). Run the
  same command again with `-C -` to resume — curl detects the partial file's
  size and continues from there.
- **gh.ddlc.top** is an alternative mirror that also supports release downloads
  (tested working). Format: `https://gh.ddlc.top/https://github.com/...`
- **File delivery** — save to `~/Desktop/hermes/` so the user can find it.
  Always verify with `ls -lh` and `file` + `unzip -l` (for zips) after download.

### General Installation Pattern for Hermes Extension Projects

Many third-party Hermes projects ship as a repo with their own `skills/` and `plugins/` directories. Install pattern:

```bash
# 1. Clone (with mirror if needed)
cd ~/Desktop
git clone https://ghproxy.net/https://github.com/user/project.git

# 2. Create venv (macOS Homebrew Python has PEP 668 protection)
cd project
/usr/local/bin/python3.13 -m venv venv   # or python3.12 on Linux
source venv/bin/activate

# 3. Install dependencies (use pip mirror for China)
pip install -r requirements.txt
# Alternative: pip install -i https://pypi.tuna.tsinghua.edu.cn/simple -r requirements.txt

# 4. Symlink skills into Hermes
for skill in skills/*/; do
    name=$(basename "$skill")
    ln -sfn "$(pwd)/skills/$name" ~/.hermes/skills/quant-$name
done

# 5. Symlink plugins into Hermes
ln -sfn "$(pwd)/plugins/<plugin_dir>" ~/.hermes/plugins/<plugin_dir>

# 6. Copy or symlink .env (project-specific env vars)
cp hermes-config/.env.example .env
# Then edit .env with your keys
```

### Version Constraint Pitfall

Check `requirements.txt` for Python version requirements before installing:

```bash
head -5 requirements.txt
# If it says "Python >= 3.12" and your system Python is 3.11, use Homebrew Python:
/usr/local/bin/python3.13 -m venv venv   # use >=3.12
```

Common indicators that signal a version mismatch:
- `ERROR: Ignored the following versions that require a different python version`
- `ERROR: Could not find a version that satisfies the requirement <package>`

### Concrete Example: quant-trade

[quant-trade](https://github.com/colinsweany/quant-trade) is a multi-asset quant trading agent built on Hermes. Verified install (Intel Mac, China network):

| Step | Command | Notes |
|------|---------|-------|
| Clone | `git clone https://ghproxy.net/https://github.com/colinsweany/quant-trade.git` | ghproxy.net mirror worked |
| Venv | `/usr/local/bin/python3.13 -m venv venv` | Requires Python ≥ 3.12 (pandas-ta) |
| Install | `pip install -r requirements.txt` | 60+ packages, ~5 min |
| Skills | `ln -sfn skills/*/ ~/.hermes/skills/quant-*` | 14 skills prefixed |
| Plugin | `ln -sfn plugins/quant_tools ~/.hermes/plugins/quant_tools` | Single plugin dir |
| Env | create `.env` with `OPENAI_API_BASE` pointing to SiliconFlow | LLM features optional |

Once installed, ask the agent to use the `quant-*` skills for stock analysis, backtesting, and factor research. A-share data (via AKShare) requires no API key and was verified working (e.g. `600519` 茅台 real-time quote).

## Camofox / Camoufox Anti-Detection Browser Setup

[Camofox](https://github.com/jo-inc/camofox-browser) is a self-hosted browser server that wraps Camoufox (a Firefox fork with C++ fingerprint spoofing) for anti-detection browsing. Useful for scraping sites with Cloudflare/bot detection.

### Installation (China Network)

```bash
# npm is pre-configured with npmmirror.com registry — still slow for Camoufox binary (~300MB)
npm install -g @askjo/camofox-browser

# Or run directly with npx (caches package):
npx @askjo/camofox-browser
```

**Camoufox binary download issues:** The npm postinstall downloads the Camoufox browser (~300MB) to `~/Library/Caches/camoufox/Camoufox.app/` (macOS). Behind the GFW this may be slow or timeout. Let it run — it will eventually complete. The GeoIP database (~66MB) is also downloaded to the same cache.

### uBlock Origin Addon Fix

The Camoufox binary attempts to download the uBlock Origin addon from `https://addons.mozilla.org/firefox/downloads/latest/ublock-origin/latest.xpi`, which is **blocked in China**. Without it, the Camoufox engine fails to launch with:

```
manifest.json is missing. Addon path must be a path to an extracted addon.
```

**Fix — create a placeholder manifest.json:**

```bash
ADDON_DIR=~/Library/Caches/camoufox/Camoufox.app/Contents/Resources/addons
mkdir -p "$ADDON_DIR/UBO"
cat > "$ADDON_DIR/UBO/manifest.json" << 'EOF'
{
  "manifest_version": 2,
  "name": "uBlock Origin",
  "version": "1.72.0",
  "description": "",
  "applications": {
    "gecko": { "id": "uBlock0@raymondhill.net" }
  }
}
EOF
```

**Path detail:** On macOS, the addon path must be inside the `.app` bundle at `Camoufox.app/Contents/Resources/addons/UBO/` — NOT at the cache root level (`~/Library/Caches/camoufox/addons/UBO/`). The camoufox-js `getPath()` function resolves relative to the bundle for macOS.

### CDP Protocol Incompatibility Fix

Camoufox v150.0.2 (alpha.25) uses a Firefox CDP protocol that does NOT accept the `isMobile` field in `Browser.setDefaultViewport`. Playwright's `browser.newContext()` internally passes `isMobile: false`, causing:

```
browser.newContext: Protocol error (Browser.setDefaultViewport): ...
Found property "<root>.viewport.isMobile" - false which is not described in this scheme
```

**Fix — patch camofox-browser server.js** (4 changes):

1. **Remove viewport from `contextOptions`** (line ~1174):
```js
// server.js — change contextOptions to use viewport: null
const contextOptions = {
  viewport: null,
  permissions: ['geolocation'],
};
```

2. **Set viewport on each new page** (after every `session.context.newPage()` call):
```js
await page.setViewportSize({ width: 1280, height: 720 }).catch(() => {});
```

Apply this after EVERY `newPage()` call in server.js — there are ~6 locations covering the main tab creation, retry paths, Google retry handler, and the legacy listItem endpoint.

**File to patch:** `/Users/mac/.local/lib/node_modules/@askjo/camofox-browser/server.js` (global install).

**IMPORTANT:** This patch is local and gets overwritten on `npm update`. Reapply after updating camofox-browser.

### Audio Autoplay Mute Fix

Camofox auto-plays audio on video pages (Douyin, etc.), surprising the user. Fix via Firefox preference in `server.js`:

```js
options.firefoxUserPrefs = {
  ...(options.firefoxUserPrefs || {}),
  'media.autoplay.default': 5,
  'media.autoplay.blocking_policy': 2,
  'media.autoplay.block-event.enabled': true,
};
```

Insert after `launchOptions()` call, before `firefox.launch()`. This is a local patch, lost on npm update.

See: `references/camofox-audio-mute.md`

### Verification

```bash
# Add to ~/.hermes/.env
echo 'CAMOFOX_URL=http://localhost:9377' >> ~/.hermes/.env

# Enable persistent browser sessions (cookies survive restarts) in config.yaml:
# Set `browser.camofox.managed_persistence: true`
```

Restart gateway after `.env` changes: `hermes gateway restart`

### Running

```bash
# Start the service (runs in foreground — use background=true or tmux for persistence)
camofox-browser

# Verify health
curl http://localhost:9377/health
# Expected: {"ok":true,"engine":"camoufox","browserRunning":true,...}

# When CAMOFOX_URL is set, all Hermes browser tools (browser_navigate, browser_click,
# browser_snapshot, etc.) automatically route through Camoufox.
```

### Pitfalls

- **Server.js patches lost on update**: The CDP protocol fix and audio mute fix are local patches. Re-check both after `npm update -g @askjo/camofox-browser`. See `references/camofox-cdp-fix.md` and `references/camofox-audio-mute.md`.
- **Addons directory path**: The Camoufox addon path on macOS is inside the `.app` bundle, not at the cache root. Re-check after binary update if the addon fix is lost.
- **Version mismatch risk**: Camoufox alpha releases may break Playwright compatibility with new CDP protocol changes. If the `isMobile` error returns after an update, re-patch server.js. If a NEW error appears, check if a newer camoufox-js version fixes it.
- **Memory usage**: ~165MB RSS with browser running, ~130MB when idle.
- **Camoufox binary version pinning**: The `version.json` at `~/Library/Caches/camoufox/version.json` controls which binary is used. Set `CAMOUFOX_INSTALL_DIR` env var to pin to a specific binary path.

### Verification

```bash
# Create a tab and fetch a page snapshot
curl -s -X POST http://localhost:9377/tabs \
  -H 'Content-Type: application/json' \
  -d '{"userId":"test","sessionKey":"test1","url":"https://example.com"}'

# Get snapshot with element refs
curl -s "http://localhost:9377/tabs/<tabId>/snapshot?userId=test"
```

## Gateway Restart Note

When using Hermes via a messaging gateway (WeChat, Telegram, etc.), you **cannot** restart the gateway from within the chat. The `/restart` slash command does not work on all platforms.

**Correct way to restart:**
```bash
hermes gateway restart
# Or:
hermes gateway stop && hermes gateway start
```
Must be run from a terminal on the host machine.

---

## Pitfalls

- **Region-locked auxiliary models**: The built-in `vision_analyze` tool may use region-blocked default models. Fix: configure auxiliary vision provider to SiliconFlow (`hermes config set auxiliary.vision.provider openai` + base_url + model). Config changes require `/reset` to take effect in the current session.
- **.env changes need restart**: Writing new env vars to `~/.hermes/.env` only takes effect after `hermes gateway restart`. Config changes via `hermes config set` also need a session reset for toolsets.
- **Balance runs out**: SiliconFlow free trial credits are limited. For production use, top up ¥10-20 which lasts hundreds of image generations.
- **Model ID format**: SiliconFlow uses full model IDs like `Qwen/Qwen-Image`, not short names. Check available models via `GET /v1/models`.
