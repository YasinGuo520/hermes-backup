# Camofox CDP Protocol Fix — Error Transcript & Patch Record

## Environment

| Key | Value |
|-----|-------|
| camofox-browser | v1.11.2 |
| camoufox-js | v0.11.1 |
| Camoufox binary | v150.0.2 (alpha.25) |
| Playwright-core | v1.61.1 |
| OS | macOS 15.0.1 (Intel) |
| Install path | /Users/mac/.local/lib/node_modules/@askjo/camofox-browser/ |

## Original CDP Error

When creating a tab (`POST /tabs`), Playwright's `Browser.setDefaultViewport` CDP call fails:

```
browser.newContext: Protocol error (Browser.setDefaultViewport): ERROR: failed to call method 'Browser.setDefaultViewport' with parameters {
  "browserContextId": "...",
  "viewport": {
    "viewportSize": { "width": 1280, "height": 720 },
    "deviceScaleFactor": 1,
    "isMobile": false
  }
}
Found property "<root>.viewport.isMobile" - false which is not described in this scheme
```

**Root cause:** Camoufox v150 (alpha) has a CDP protocol that doesn't accept `isMobile` in `Browser.setDefaultViewport`. Playwright 1.61.x always sends `isMobile: false` when creating a context with a viewport.

## Initial Addon Error (China-specific)

Before the CDP error, the engine couldn't start:

```
"manifest.json is missing. Addon path must be a path to an extracted addon."
```

uBlock Origin download from `addons.mozilla.org` fails (blocked in China). Fix: create placeholder manifest.json at `Camoufox.app/Contents/Resources/addons/UBO/`.

## Patches Applied

File: `/Users/mac/.local/lib/node_modules/@askjo/camofox-browser/server.js`

### Patch 1: contextOptions — use viewport: null

```js
const contextOptions = {
  viewport: null,                    // was: { width: 1280, height: 720 }
  permissions: ['geolocation'],
};
```

Setting `viewport: null` tells Playwright to skip `Browser.setDefaultViewport` during `newContext()`.

### Patches 2-6: Set viewport after each newPage()

```js
await page.setViewportSize({ width: 1280, height: 720 }).catch(() => {});
```

Applied after every `session.context.newPage()` call (~6 locations):

| Location | Route | Description |
|----------|-------|-------------|
| ~2610 | POST /tabs | Main tab creation |
| ~2638 | POST /tabs | Proxy rotation retry |
| ~2810 | POST /tabs | Google block retry |
| ~1683 | internal | Google session rotation |
| ~5309 | POST /listitems/open | Legacy endpoint |
| ~5336 | POST /listitems/open | Legacy proxy retry |

## Future-Proofing

If Camoufox fixes the CDP issue: reinstall (`npm i -g @askjo/camofox-browser`) and re-check. If a NEW error appears, update camoufox-js via the same reinstall, then re-apply patches if needed.
