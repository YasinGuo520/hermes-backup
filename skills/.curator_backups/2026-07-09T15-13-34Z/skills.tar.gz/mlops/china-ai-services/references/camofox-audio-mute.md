# Camofox 自动播放音频静音配置

## 问题

通过 Camofox 浏览器访问含有视频/音频的页面（如抖音视频链接）时，浏览器会自动播放音频，导致突然有声音从电脑扬声器输出，干扰用户。

## 根因

Camofox 底层是 Firefox 浏览器，默认允许媒体自动播放（`media.autoplay.default=0`）。访问抖音等含视频的网页时，页面 JS 自动触发播放。

## 修复方法

在 `server.js` 的 `launchBrowserInstance()` 函数中，`firefox.launch()` 之前注入 Firefox 用户偏好：

### 要修改的文件

`~/.local/lib/node_modules/@askjo/camofox-browser/server.js`

### 修改位置

在 `launchOptions()` 调用之后，`firefox.launch()` 之前，添加：

```js
// Mute all autoplay audio (avoid blasting sound when visiting video pages)
options.firefoxUserPrefs = {
  ...(options.firefoxUserPrefs || {}),
  'media.autoplay.default': 5,           // 5 = block all autoplay
  'media.autoplay.blocking_policy': 2,   // strict blocking
  'media.autoplay.block-event.enabled': true,
};
```

### 代码上下文（server.js ~line 981）

```js
const options = await launchOptions({ ... });
// ← 在这里插入 firefoxUserPrefs
options.proxy = normalizePlaywrightProxy(options.proxy);
await pluginEvents.emitAsync('browser:launching', { options });
candidateBrowser = await firefox.launch(options);  // ← 启动前生效
```

### Firefox `media.autoplay.*` 参数说明

| 偏好 | 值 | 效果 |
|------|-----|------|
| `media.autoplay.default` | `0` = 允许, `1` = 阻止有声, `5` = 阻止所有 | 设为 `5` 完全阻止自动播放 |
| `media.autoplay.blocking_policy` | `0` = 严格, `2` = 持久严格 | 设为 `2` 防止用户交互后解封 |
| `media.autoplay.block-event.enabled` | `true` | 阻止 autoplay 事件触发 |

## 注意事项

- **npm update 后丢失**：该补丁是本地修改，`npm update -g @askjo/camofox-browser` 后会覆盖，需重新打补丁。
- **不影响手动播放**：用户主动点击播放按钮的视频仍然有声音，只阻止 JS 自动播放。
- **与 CDP 补丁共存**：此修改与 `references/camofox-cdp-fix.md` 中的 viewport 补丁不冲突，可同时存在。
