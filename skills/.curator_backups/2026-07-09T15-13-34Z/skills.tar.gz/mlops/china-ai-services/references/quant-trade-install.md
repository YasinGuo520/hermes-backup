# quant-trade Installation Reference

**Repo:** https://github.com/colinsweany/quant-trade  
**License:** MIT  
**Stars:** 37 (as of 2026-07)  
**Lines:** ~13,000 Python, 460+ tests  

## What It Is

Multi-asset quant trading agent on Hermes-Agent. Covers crypto (auto-execution), A-shares (signal-only), HK/US stocks (backtest/research). Built-in backtest engine, factor lab (36+ factors), strategy generator, LLM factor mining, ArXiv paper search, macro data (19 FRED indicators + VIX), and decision engine.

## A-Share Tools (Verified Working ✅)

19 tools via AKShare (free, no API key). Verified with 600519 (茅台):

| Tool | What it does | Verified |
|------|-------------|----------|
| `get_stock_quote` | Real-time quote + change% | ✅ 1206.91 +1.04% |
| `get_stock_klines` | Daily/minute K-lines | — |
| `get_stock_signal` | MA + RSI combined signal | — |
| `get_stock_valuation` | PE/PB/PS + historical percentile | — |
| `get_stock_financial` | 3 financial statements | — |
| `get_stock_financial_growth` | Revenue/profit YoY growth | — |
| `get_stock_basic` | Industry/IPO date/shares out | — |
| `get_stock_main_business` | Business breakdown | — |
| `get_stock_forecast` | Earnings forecast (market-wide) | — |
| `get_stock_express` | Preliminary earnings | — |
| `get_stock_research_reports` | Analyst reports + rating | — |
| `get_index_kline` | Index daily/weekly/monthly bars | — |
| `get_industry_ranking` | Shenwan sector return rank | — |
| `get_industry_leaders` | Top stocks in a sector | — |
| `get_concept_ranking` | Concept theme return rank | — |
| `get_northbound_flow` | Northbound (HK→A) net buy | — |
| `get_lhb_detail` | Dragon-Tiger List seats | — |
| `get_stock_news` | Stock news event stream | — |
| `compute_stock_factors` | 30+ technical factors | — |

## Installation Notes

**Environment:** Python 3.13 venv at `~/Desktop/quant-trade/venv/`  
**Skill prefix:** `quant-` (14 skills symlinked)  
**Plugin:** `quant_tools` at `~/.hermes/plugins/quant_tools`  
**Activation:** `cd ~/Desktop/quant-trade && source venv/bin/activate`

## LLM Features

For factor mining and decision engine, needs OpenAI-compatible API. Configured to use SiliconFlow (China): set `OPENAI_API_BASE=https://api.siliconflow.cn/v1` and `LLM_MODEL=Qwen/Qwen3-235B-A22B-Instruct` in the project's `.env`.

## Limitation: Installer

The stock (`get_stock_*`) tools require `akshare>=1.13` and work out of the box in the venv with no API key. The crypto side (`ccxt`) needs exchange API keys configured.

## Activation Workflow

When user asks to analyze a stock:
1. Source the venv: `cd ~/Desktop/quant-trade && source venv/bin/activate`
2. Import from `plugins.quant_tools.stock_tools` (A-share functions) or `plugins.quant_tools.financial_stock_tools` (valuation/financials)
3. Each handler takes `dict` with `symbol` key (e.g. `{'symbol': '600519'}`)
4. Return is JSON string
