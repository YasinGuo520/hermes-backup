---
name: scheduled-content-pipeline
description: "Use when setting up cron jobs that regularly aggregate web content, filter, format, and push structured reports to the user. Covers multi-source search strategy, filtering criteria, fixed-format output templates, and delivery configuration."
version: 1.0.0
author: Yasin's AI副驾驶
license: MIT
metadata:
  hermes:
    tags: [cron, content-pipeline, daily-briefing, automation]
    related_skills: []
---

# Scheduled Content Pipeline

## Overview

This skill captures the pattern of building **daily cron jobs that aggregate, verify, filter, format, and push structured content reports** to the user. Used for setups like daily AI news digests, curated industry briefings, or any recurring content roundup requiring web research + structured output.

The user already runs this pattern for:
- AI英语每日一练 (daily English snippet from trending AI docs, 8:00 AM)
- 今日AI资讯含Agent变现实战 (daily AI news + Agent monetization, 8:30 AM)

## When to Use

- User asks: "set up a daily X push" / "定时推送Y" / "每天早上Z点推给我"
- Deliverable is a cron job that **sources, filters, and formats** external content — not just a static reminder
- Output has a **fixed-format structure** (multiple sections, annotations per item)

**Do NOT use for:**
- Simple reminders — use basic cron with no web search
- Static daily tips without research
- One-shot content without recurring delivery

## Five-Layer Prompt Architecture

Every scheduled content pipeline prompt is composed of five layers:

### Layer 1: Role + Mission
```
你是每日X全自动推送机器人，执行以下任务：
## 任务目标
采集并整理当日（今天/最新）X内容，按固定格式推送。
不得重复旧闻，不添加多余开场白结束语。
```

### Layer 2: Search Strategy (Chinese + English)
```
## 信息采集步骤
1. web_search 以下关键词（每个前5条，去重）：
   - [3-5 中文关键词]
   - [3-5 英文关键词]
2. 重要链接 → web_extract 验证正文真实性
3. 仅保留：权威媒体 + 官方发布 + 真实案例
4. 彻底过滤：营销软文、小道消息、重复内容、纯娱乐
```

Rules:
- Mix Chinese + English queries for domestic AND international coverage
- For monetization/赚钱 content, add platform-specific queries (GPTs Store, Coze, Dify, etc.)

### Layer 3: Fixed Format Structure (strict order, never deviate)
```
## 固定排版结构（顺序不可更改）
标题：《今日XX汇总》

① 头条重点（N条）
每条格式：**标题**｜一句话核心摘要

② [Section Name]（N条）
每条格式：**标题**｜一句话核心摘要

③ ...
```
Rules: consistent per-item format (bold title | summary), no emoji clutter, no extra symbols, direct output with no 开场白 or 结束语.

### Layer 4: Domain-Specific Annotation
When content has special metadata, annotate per item. Example for Agent monetization:
```
每条格式：**标题**｜核心摘要 + **【智能体】**工具名 + **【变现】**模式
```

### Layer 5: Quality Gates
```
## 输出规范
- 重点关键词用 **加粗**
- 篇幅适中（合计X-Y条）
- 当天搜不到足够新内容时，宁少勿滥，不凑数
- **核心要求**：[domain-specific quality bar]
```

## USER CONTENT PREFERENCES (must embed)

From session history with Yasin:

1. **变现/赚钱 section**: prioritize **personal/small-team** over enterprise. At least **4 out of 6-8 items** must be individual-level.
2. Each item must specify: **【智能体】** which tool + **【变现】** which model + concrete earning number.
3. Enterprise cases: max **1-2** per section.
4. Everything must be **"拿来就能参考"** — immediately actionable, not theoretical.
5. "写清楚XX用XX工具通过X方式赚了多少钱" — not vague claims like "可月入过万" but specifics like "月入$1,400".

## Delivery Configuration

```
cronjob action='create' name="..." schedule="30 8 * * *"
  deliver="origin"                   # push to current chat
  enabled_toolsets=["web","terminal"]# restrict tools, save tokens
```

- Schedule in **Beijing time** (UTC+8)
- `enabled_toolsets=["web","terminal"]` prevents loading unnecessary tools
- For the first run, manually verify before leaving on cron: `cronjob action='run' job_id=xxx`

## Common Pitfalls

1. **Old news repeated.** Cron agent has no memory of past runs. Prompt must say "不得重复旧闻" — trust the agent to search today's content.
2. **Too many enterprise examples.** For 变现 sections, explicitly constrain ratio (个人级≥4, 企业级≤2).
3. **Vague earnings.** Force concrete numbers in the prompt — not "可月入过万" but specify the format.
4. **No source verification.** Force `web_extract` on important links to verify claims.
5. **Over-stuffing.** "当天搜不到足够新内容时，宁少勿滥，不凑数" prevents inventing or rehashing old content.
6. **All tools loaded.** Without `enabled_toolsets`, cron agent loads every tool — wasteful and risky.

## Verification Checklist

- [ ] Prompt has all 5 layers (Role, Search, Format, Annotation, Quality)
- [ ] Chinese + English search queries included
- [ ] 变现 section has personal-level ratio enforced (≥4 personal, ≤2 enterprise)
- [ ] Concrete earning numbers required
- [ ] Tool and monetization model annotated per item where relevant
- [ ] Output format specifies: no greetings/closings, bold for keywords
- [ ] "宁少勿滥" fallback rule included
- [ ] `enabled_toolsets` restricted to `["web","terminal"]`
- [ ] Schedule is Beijing time (UTC+8)
- [ ] Run manually once to verify output before leaving on cron

See `references/ai-news-agent-monetization-prompt.md` for the full working prompt template.