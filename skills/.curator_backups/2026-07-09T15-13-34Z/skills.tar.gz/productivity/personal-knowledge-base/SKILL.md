---
name: personal-knowledge-base
description: Build and maintain a personal knowledge base inside an Obsidian vault using the Karpathy wiki pattern. Ingest sources, create interlinked notes, file queries, and keep an append-only action log.
trigger: |-
  User asks to create a knowledge base, wiki, or note system
  User asks to save/archive/organize research, ideas, or learnings
  User references their vault, notes, or personal wiki
  User says "记下来" / "存到知识库" / "帮我整理到笔记" / "总结" + "存放起来" / "生成xmind" / "关联到obsidian"
  [AUTO-TRIGGER] conversation produces substantive content: research findings, decisions, plans >3 steps, comparative analysis with >3 items, price/feasibility calculations, ranked recommendations, any output the user would reference again. Proactively evaluate and archive without being asked. Do NOT ask "应该存吗" — just evaluate, archive if valuable, and report what you did in one line.
languages: [zh-CN, en]
---

# Personal Knowledge Base (个人知识库)

Build and maintain an interlinked knowledge base inside the user's Obsidian vault. Based on the Karpathy LLM Wiki pattern.

## Vault Path

Check `memory` for a stored path. Fallback:
- macOS: `~/Documents/Obsidian Vault`
- Linux: `~/Documents/Obsidian Vault`

Resolve once per session; save to `memory` after first resolution.

## Structure

Place the KB at `{Vault}/_kb/`:

```
Vault/_kb/
├── SCHEMA.md        ← Domain rules, naming, tags, page thresholds
├── index.md         ← Content catalog (sectioned, one-line summary per page)
├── log.md           ← Append-only action log
├── raw/             ← Immutable source material
│   ├── articles/
│   ├── clippings/
│   └── assets/
├── entities/        ← People, products, tools, companies
├── concepts/        ← Methods, theories, frameworks
└── queries/         ← Filed Q&A results
```

## Initialization

```bash
VAULT="~/Documents/Obsidian Vault"
mkdir -p "$VAULT/_kb/raw/articles" "$VAULT/_kb/raw/clippings" "$VAULT/_kb/raw/assets" "$VAULT/_kb/entities" "$VAULT/_kb/concepts" "$VAULT/_kb/queries" "$VAULT/_kb/prompts"
```

Then write three files with YAML frontmatter:
- `_kb/SCHEMA.md` — domain, conventions, tag taxonomy
- `_kb/index.md` — empty catalogs with header
- `_kb/log.md` — initialization entry

## Ingestion

When the user provides a source (URL, article, idea, transcript):

1. **Capture raw** → save to `_kb/raw/articles/` or `_kb/raw/clippings/` with frontmatter (`source_url`, `ingested`, `sha256`)
2. **Check existing** → read `index.md` + `search_files` across `entities/` and `concepts/`
3. **Write/update** → if entity/concept appears in 2+ sources or is central to one → create page at `entities/` or `concepts/`. Otherwise, append to existing page.
4. **Cross-reference** → each page needs ≥2 `[[wikilinks]]` outbound links
5. **Index** → add new pages to `index.md` under correct section
6. **Log** → append to `log.md` with list of created/updated files
7. **Report** → tell user what changed

### Video/Audio Source Ingestion (Douyin, Bilibili, etc.)

When the source is a short-video or audio platform (no direct transcript API):

1. **Browser approach** — use Camofox to navigate to the URL. If the page loads with a login wall:
   - Take a `browser_vision` screenshot to extract the video title, author, hashtags, and any visible text overlay
   - Note the duration, engagement stats, and chapter markers from the accessibility tree
2. **Fallback to web search** — if login blocks full video content, search for:
   - The video title + author to find related written content (GitHub guides, Zhihu articles, blog posts)
   - The platform's topic/hashtag to find community discussions
3. **Synthesize** — combine platform metadata + searched written content into a coherent summary. Note in the frontmatter that content was derived from video metadata + related sources (not a direct transcript)
4. **Mind map supplement** — for content with a clear hierarchical structure (e.g. numbered paths/levels/steps), generate a FreeMind `.mm` mind map using the `mind-map` skill and save to `raw/assets/`
5. **Continue with normal ingestion** — index + log + report

### Supplementary Assets (Mind Maps)

For content that benefits from visual hierarchy (ranked lists, path-based guides, taxonomies):

- Generate a `.mm` file in `_kb/raw/assets/` using the `mind-map` skill
- Keep the mind map as a 3-4 level max hierarchy for readability
- Reference it from the clipping note via: `**关联文件**：[[raw/assets/<filename>.mm]]`
- Also save a copy to `~/Desktop/hermes/` for quick desktop access

## Auto-Archive (Conversation-to-KB)

When auto-trigger fires (substantive conversation content), do NOT ask "should I save this?" — just evaluate, archive if valuable, report in one line.

### What qualifies for auto-archive

- **Research findings** from web searches or data analysis
- **Comparative analyses** with >3 items (rankings, path evaluations, side-by-side comparisons)
- **Execution plans** with >3 steps that the user would re-read later
- **Feasibility / price / ROI calculations** specific to the user's context
- **Decisions made** with reasoning (why path A over path B)
- **Any output the user explicitly said "存下来" / "总结一下" / "放到知识库" about**

### Derivative content

When the user provides source A (e.g. a video link) and then asks for analysis/ranking/execution plan on the same topic, that analysis is derivative content. Archive BOTH the raw source AND the derivative analysis:

- Source → `raw/clippings/` or `raw/articles/`
- Derivative → `raw/articles/` with a `related:` frontmatter field linking back to the source

### Filing rules (auto-archive)

Match content to the right directory:

| Content type | Target | Frontmatter hint |
|---|---|---|
| URL/share/clip | `raw/clippings/` | `source_url:` |
| Analysis/ranking/plan | `raw/articles/` | `type: analysis` |
| Decision rationale | `entities/` or `concepts/` | `type: entity` |
| Research Q&A | `queries/` | `type: query` |

### What NOT to archive

- One-off trivial Q&A ("what time is it", "search for X") unless the answer is a durable fact
- Session-specific troubleshooting steps (env errors, install failures)
- Casual chat / greetings
- Content already in the KB that hasn't changed

## Query

When the user asks a KB question:

1. Read `index.md` for relevant pages
2. `search_files` across `entities/` and `concepts/`
3. Read relevant pages, synthesize answer with `[[wikilinks]]` citations
4. If answer is a substantial new synthesis → file to `queries/`

## Prompt Library (prompts/)

A reusable prompt template library can live inside the KB:

```
_kb/prompts/
├── README.md              ← 使用说明 + 核心公式
├── 带货/
│   └── 直播话术.md         ← 话术生成、选品分析、逼单
├── 短视频/
│   └── 短视频脚本.md       ← 脚本、标题、开头钩子
├── 自媒体/
│   └── AI内容.md           ← 测评、教程、干货合集
└── 通用/
    └── 通用Prompt.md       ← 润色、总结、翻译、改写
```

**Prompt library rules:**
- Each note is a copy-paste template with `[填写]` placeholder slots
- Categorize by use case, not by model
- Every note uses frontmatter: `type: prompt`, `tags: [prompt, ...]`
- Add a `README.md` explaining the core formula and iteration pattern
- Update `index.md` with a Prompts section linking each category

## Frontmatter Standard

```yaml
---
title: Page Title
created: YYYY-MM-DD
updated: YYYY-MM-DD
type: entity | concept | query | raw | meta | prompt
tags: [tag1, tag2]
sources: [source description]
---
```

## Pitfalls

- Vault paths may contain spaces → use `read_file`/`write_file`, not shell commands
- Don't create files at vault root → use `_kb/` subdirectory
- Don't modify existing Obsidian defaults (`欢迎.md`, etc.)
- Save the vault path to `memory` after the first session
- For deep wiki management (linting, archiving, bulk ingest, health checks), load `llm-wiki` skill

## Reference Files

- `references/macos-calendar-applescript.md` — Create/manage macOS Calendar events via AppleScript
- `references/douyin-video-ingestion.md` — Extracting content from Douyin videos (no transcript API, login wall bypass via synthesis)
