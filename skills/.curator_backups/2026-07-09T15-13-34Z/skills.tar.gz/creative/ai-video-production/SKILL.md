---
name: ai-video-production
description: 全自动AI视频生产流水线——使用本地Python工具（moviepy + edge-tts + ffmpeg）从文案到成品MP4的端到端自动化。无需GPU，无需云API。适用于抖音带货素材、知识科普、工具测评等竖屏短视频。
triggers:
  - AI视频生成
  - 自动视频
  - 视频合成
  - moviepy
  - edge-tts
  - TTS配音
  - 竖屏视频
  - Python视频
  - 文字转视频
  - 带货视频
related:
  - ai-video-content-creation  # 互补技能：云端AI视频平台生成
platforms: [macos, linux]
---

# AI Video Production（全自动AI视频生产流水线）

使用本地 Python 工具（moviepy + edge-tts + ffmpeg）从文案到成品 MP4 的端到端自动化流水线。**无需 GPU，无需云 API 调用**，全在本机运行。

**适用范围：** 抖音带货视频、AI工具测评、知识科普、产品介绍等竖屏短视频。

**与 `ai-video-content-creation` 的关系：** 互补。该技能走云端AI平台（小云雀/即梦），本技能走本地Python全自动。前者适合高质量视觉素材，后者适合快速、低成本、可批量生产的内容。

---

## 流水线架构

```
┌──────────────────────────────────────────────────────┐
│               AI 视频生产流水线                         │
├──────────────────────────────────────────────────────┤
│                                                      │
│  Hermes (我)            工具             输出           │
│  ──────────────────────────────────────────────       │
│  ① 写文案 + 分镜        —              → 脚本文本     │
│  ② 生成幻灯片    →  moviepy.TextClip   → PNG帧        │
│  ③ 生成配音      →  edge-tts(Python)   → MP3语音      │
│  ④ 合成视频      →  moviepy + ffmpeg   → MP4成品      │
│                                                      │
└──────────────────────────────────────────────────────┘
```

---

## 前置依赖

```bash
# 必装
pip3 install moviepy pydub edge-tts numpy -i https://pypi.tuna.tsinghua.edu.cn/simple

# ffmpeg 需已安装（macOS 可 brew install ffmpeg）
which ffmpeg
```

**注意：** 用 `pip3` 而非 `pip`，确保与 `python3` 对应。如遇 `ModuleNotFoundError`，在脚本头加：
```python
import sys, site
sys.path.insert(0, site.getusersitepackages())
```

---

## 核心工作流

### 1. 文案 & 分镜设计

写脚本时按「镜头」划分，每个镜头指定：**时长 + 画面描述 + 配音文案**。

**分镜模板：**

| # | 时间 | 画面 | 文案 |
|---|------|------|------|
| 1 | 0-5s | 标题封面，大字标题+小字副标题 | (无/开场白) |
| 2 | 5-10s | 痛点画面，问题描述 | "你花3小时做XX？..." |
| 3 | 10-16s | 方案介绍，工具/产品展示 | "今天测评这个..." |
| 4 | 16-24s | 步骤说明，分步卡片 | "怎么用？三步..." |
| 5 | 24-30s | 对比/效果展示 | "以前...现在..." |
| 6 | 30-35s | 结果验证 | "关键是真的能落地..." |
| 7 | 35-45s | CTA关注 | "关注我，下期..." |

**文案要求：**
- 配音语速按 **260-280字/分钟** 估算
- 45秒视频 ≈ 180-220字
- 段落之间留自然停顿

### 2. 生成幻灯片（moviepy TextClip）

**重要：moviepy 2.x API 与 1.x 差异较大，以下为 2.x 正确用法。**

```python
from moviepy import VideoClip, TextClip, CompositeVideoClip

W, H = 720, 1280  # 竖屏 9:16

def solid_bg(color):
    """返回纯色帧函数 — frame_function 参数名！"""
    def make_frame(t):
        import numpy as np
        frame = np.zeros((H, W, 3), dtype=np.uint8)
        frame[:] = color
        return frame
    return make_frame

# 创建背景
bg = VideoClip(frame_function=solid_bg((18, 18, 30)), duration=5.0)

# 创建文字
title = TextClip(
    text="标题文字",
    font="/System/Library/Fonts/STHeiti Medium.ttc",  # macOS中文字体
    font_size=52,          # 720p 下 52pt 合适
    color="white",
    stroke_color="#6C63FF",
    stroke_width=1,
    size=(W - 120, None),  # 左右留边距
    method="caption",       # 2.x 用 caption 而非 label
    text_align="center",
).with_duration(5.0).with_position(("center", H // 2 - 80))

# 合成
composite = CompositeVideoClip([bg, title], size=(W, H))
```

**关键 API 差异（2.x vs 1.x）：**

| 概念 | 1.x | 2.x |
|------|-----|-----|
| 帧函数参数 | `make_frame` | `frame_function` |
| 帧返回值 | tuple `(0,0,0)` | numpy array `np.zeros((H,W,3))` |
| TextClip.text | `txt` 参数 | `text` 参数 |
| TextClip.method | `label`(默认) | `caption`(推荐，自动换行) |
| 设置时长 | 构造时传 | `.with_duration(n)` |
| 设置位置 | 构造时传 | `.with_position(x, y)` |
| 截取片段 | `.subclip(s, e)` | `.subclipped(s, e)` |
| 合并视频 | `concatenate_videoclips` | 同名但 method='compose' |
| 加音频 | `.set_audio(a)` | `.with_audio(a)` |

### 3. 生成配音（edge-tts）

```python
import edge_tts, asyncio

communicate = edge_tts.Communicate(
    "配音文本内容",
    voice="zh-CN-XiaoxiaoNeural",  # 中文女声，自然清晰
    rate="+15%",   # 语速加快15%（适配短视频节奏）
    pitch="+0Hz"
)
asyncio.run(communicate.save("/path/to/output.mp3"))
```

**推荐中文语音选项：**

| 语音 | 性别 | 风格 | 适合场景 |
|------|------|------|---------|
| `zh-CN-XiaoxiaoNeural` | 女 | 自然亲切 | **通用推荐** |
| `zh-CN-YunxiNeural` | 男 | 活力 | 测评/科技 |
| `zh-CN-YunjianNeural` | 男 | 专业 | 知识科普 |
| `zh-CN-XiaoyiNeural` | 女 | 活泼 | 带货/种草 |

### 4. 合成视频（带音频对齐）

```python
from moviepy import AudioFileClip

audio = AudioFileClip("voiceover.mp3")
video = concatenate_videoclips(slides, method="compose")

# 对齐时长
final_dur = min(video.duration, audio.duration)
video = video.subclipped(0, final_dur)
audio = audio.subclipped(0, final_dur)
video = video.with_audio(audio)

# 输出
video.write_videofile(
    "output.mp4",
    fps=24,
    codec="libx264",
    audio_codec="aac",
    preset="ultrafast",  # 无独显机器用 ultrafast
    bitrate="1500k",
    threads=4,
)
```

---

## 性能优化（Intel Mac 无独显）

| 优化项 | 建议值 | 效果 |
|--------|--------|------|
| 分辨率 | 720×1280（非1080p） | 帧数减少55% |
| 编码预设 | `ultrafast`（非 medium） | 速度提升3-5倍 |
| 码率 | 1500k（非 3000k） | 渲染更快，文件更小 |
| 帧率 | 24fps | 够用 |
| 线程数 | 4（i7 4核8线程） | 充分利用CPU |

**实测数据（MacBook i7-1068NG7）：**
- 1080p medium → ~1.1fps 渲染，~18分钟/50秒视频
- 720p ultrafast → ~2.7fps 渲染，~6.5分钟/50秒视频（包含语音生成时间）

---

## macOS 字体注意

| 字体路径 | 支持中文 | 说明 |
|---------|:-------:|------|
| `/System/Library/Fonts/STHeiti Medium.ttc` | ✅ | **推荐**，简化字，粗体适中 |
| `/System/Library/Fonts/PingFang.ttc` | ✅ | 但 PIL/ImageFont 可能报错 |
| `/Library/Fonts/Arial Unicode.ttf` | ✅ | 可用但字形较老 |
| `/System/Library/Fonts/Hiragino Sans GB.ttc` | ✅ | 细体，适合副标题 |

**PingFang.ttc 报错解决：** 如果报 `cannot open resource`，换用 `STHeiti Medium.ttc`。`.ttc` 是集合字体格式，PIL 不一定能打开所有索引。

---

### 字幕/副标题位置规则（用户偏好）

| 元素 | 位置 | 说明 |
|------|------|------|
| **主标题** | `(center, H//2 - 120)` | 居中偏上 |
| **副标题/解说文字** | `(center, H - 180)` | **底部**，不要放中间 |

### 程序化渐变背景（AI生图质量不足时的回退方案）

当用户反馈「图太low了」「没有科技感」时，**立即切换到此方案**，不要继续优化AI生图提示词。

```python
def gradient_bg(color_top, color_bot):
    def make_frame(t):
        import numpy as np
        frame = np.zeros((H, W, 3), dtype=np.uint8)
        for y in range(H):
            ratio = y / H
            frame[y, :] = [
                int(color_top[0]*(1-ratio) + color_bot[0]*ratio),
                int(color_top[1]*(1-ratio) + color_bot[1]*ratio),
                int(color_top[2]*(1-ratio) + color_bot[2]*ratio),
            ]
        return frame
    return make_frame
```

推荐配色（科技深色主题）：

| 场景 | 顶色(RGB) | 底色(RGB) | 风格 |
|------|-----------|-----------|------|
| 标题/开场 | (10,10,50) | (40,10,80) | 蓝紫科技 |
| 痛/警告 | (50,10,10) | (80,20,20) | 红强调 |
| 工具/产品 | (10,20,60) | (20,40,100) | 蓝光 |
| 步骤/教程 | (10,10,40) | (30,20,70) | 紫蓝 |
| 对比 | (40,10,10) | (10,40,10) | 红→绿 |
| 结果/肯定 | (10,30,20) | (20,60,40) | 绿科技 |
| CTA/关注 | (20,10,50) | (50,20,90) | 紫发光 |

### ⚠️ VideoFileClip + 淡入淡出不兼容

永远不要对包含 VideoFileClip 的 CompositeVideoClip 应用 FadeIn/FadeOut。会导致：
```
AttributeError: 'NoneType' object has no attribute 'get_frame'
```

原因：FadeIn/FadeOut 创建 mask 触发 clip 变换，VideoFileClip reader 在复合剪辑中被关闭。

正确做法有两个：

#### 方案A：硬切（最稳）

循环短视频做背景，直接拼接硬切：

```python
def make_slide(bg_clip, title_text, subtitle_text, duration):
    bg_dur = bg_clip.duration
    loops = max(1, math.ceil(duration / bg_dur))
    parts = [bg_clip] * loops
    bg_looped = concatenate_videoclips(parts, method="chain")
    bg_segment = bg_looped.subclipped(0, duration).resized((W, H))
    # ... 叠加文字 ...
    return CompositeVideoClip(clips, size=(W, H))
```

#### 方案B：交叉溶解 CrossFadeIn（推荐，平滑过渡）

**已验证可用。** `CrossFadeIn` 来自 `moviepy.video.fx`，与 VideoFileClip 兼容：

```python
from moviepy.video.fx import CrossFadeIn

slides = [...]  # 所有分镜已完成

OVERLAP = 0.3  # 重叠时长（秒）
composite_clips = []
current_t = 0.0
for i, s in enumerate(slides):
    if i > 0:
        # 第二帧开始加 CrossFadeIn 渐显
        s = s.with_effects([CrossFadeIn(OVERLAP)])
    composite_clips.append(s.with_start(current_t))
    current_t += s.duration - OVERLAP

video = CompositeVideoClip(composite_clips, size=(W, H))
video = video.with_duration(current_t + slides[-1].duration)
```

**原理：** 两帧重叠 OVERLAP 秒，上一帧渐隐的同时下一帧渐现。不经过黑屏，画面连续。

**注意事项：**
- `CrossFadeIn` 只影响叠加层中靠后的帧，前一帧（无 CrossFadeIn）维持原透明度
- 第一帧不加 CrossFadeIn（直接显示），最后一帧不特殊处理（自然结束）
- 最终视频总时长 = 所有分镜时长之和 - (分镜数-1) × OVERLAP
- 不要混合使用 FadeIn/FadeOut + CrossFadeIn — 两者生效机制冲突

### Wan2.2视频作为动态背景

流程：
1. 调SiliconFlow Wan2.2 T2V生成氛围视频（约5秒竖屏）
2. 循环该视频至所需总时长
3. 作为背景叠加文字和配音

详见 `references/wan-t2v-pipeline.md`

## 常见坑点

| 问题 | 原因 | 解决 |
|------|------|------|
| `ModuleNotFoundError: No module named 'moviepy'` | Python 路径问题 | 脚本头加 `sys.path.insert(0, site.getusersitepackages())` |
| `tuple' object has no attribute 'shape'` | frame 函数返回了 tuple 而非 numpy array | 返回 `np.zeros((H,W,3), dtype=np.uint8)` |
| `Invalid font ... cannot open resource` | PIL 无法打开 .ttc 字体 | 换用 `STHeiti Medium.ttc` |
| `end_time should be smaller or equal to the clip's duration` | audio/video 时长差太小 | 用 `min(dur1, dur2)` 统一裁剪 |
| TTS 无输出/报错 | edge-tts 网络问题 | 重试，或检查 `voice` 参数名 |
| 渲染超慢 | 1080p + medium preset | 降为 720p + ultrafast |
| background 进程报 `ModuleNotFoundError` | 后台进程 PYTHONPATH 不同 | 用 foreground 终端执行 |
| 视频突然出声 | Camofox 自动播放 | 打 firefoxUserPrefs 静音补丁（见 hermes-china-setup） |

---

## 完整示例脚本

参考 `references/build-script-template.md` 获取可复用的完整 Python 脚本模板。

使用方法：
1. 复制模板
2. 修改 `TTS_TEXT`（配音文案）
3. 修改 `SCENES`（分镜配置）
4. 运行 `python3 build_video.py`
