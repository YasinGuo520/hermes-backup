#!/usr/bin/env python3
"""
硅基流动 (SiliconFlow) 图像生成脚本
在 Hermes image_generate 工具不兼容时使用

用法:
  python3 siliconflow_gen.py "一只可爱的小猫" /Users/mac/Desktop/cat.png

要求:
  - 环境变量 SILICONFLOW_API_KEY 或修改下方 API_KEY
  - pip install -q requests（或使用 urllib，已内置）
"""

import os, sys, json, urllib.request

API_KEY = os.environ.get("SILICONFLOW_API_KEY") or "sk-你的key"
API_URL = "https://api.siliconflow.cn/v1/images/generations"
DEFAULT_MODEL = "Qwen/Qwen-Image"
DEFAULT_SIZE = "1024x1024"


def generate(prompt: str, output_path: str, model: str = DEFAULT_MODEL, size: str = DEFAULT_SIZE) -> str:
    """调用 SiliconFlow API 生成图像并保存到本地"""
    req = urllib.request.Request(
        API_URL,
        data=json.dumps({
            "model": model,
            "prompt": prompt,
            "n": 1,
            "size": size,
        }).encode(),
        headers={
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json",
        },
    )

    print(f"正在生成: {prompt[:60]}...")
    resp = json.loads(urllib.request.urlopen(req, timeout=120).read())
    url = resp["data"][0]["url"]

    urllib.request.urlretrieve(url, output_path)
    file_size = os.path.getsize(output_path)
    print(f"✅ 已保存: {output_path} ({file_size / 1024:.0f}KB)")
    return output_path


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("用法: python3 siliconflow_gen.py <提示词> <输出路径> [模型名] [尺寸]")
        print("示例: python3 siliconflow_gen.py '可爱小猫' /tmp/cat.png Qwen/Qwen-Image 1024x1024")
        sys.exit(1)

    prompt = sys.argv[1]
    output = sys.argv[2]
    model = sys.argv[3] if len(sys.argv) > 3 else DEFAULT_MODEL
    size = sys.argv[4] if len(sys.argv) > 4 else DEFAULT_SIZE

    generate(prompt, output, model, size)
