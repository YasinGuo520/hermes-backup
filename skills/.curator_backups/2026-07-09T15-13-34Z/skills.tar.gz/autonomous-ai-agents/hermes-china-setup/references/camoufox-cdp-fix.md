# Camoufox CDP 协议兼容补丁

## 错误现象

创建 Tab 时返回：
```
browser.newContext: Protocol error (Browser.setDefaultViewport): ERROR: failed to call method
'Browser.setDefaultViewport' with parameters {
  "browserContextId": "...",
  "viewport": { "viewportSize": { "width": 1280, "height": 720 },
    "deviceScaleFactor": 1, "isMobile": false }
}
Found property "<root>.viewport.isMobile" - false which is not described in this scheme
```

## 原因

Camoufox v150.0.2 (alpha.25) 的 Firefox CDP 协议不识别 Playwright 1.61 传递的 `isMobile` 字段。该字段在标准 Firefox CDP 中不存在。

## 修复步骤

位置：`~/.local/lib/node_modules/@askjo/camofox-browser/server.js`

### Step 1: contextOptions 移除 viewport

修改前：
```js
const contextOptions = {
  viewport: { width: 1280, height: 720 },
  permissions: ['geolocation'],
};
```

修改后：
```js
const contextOptions = {
  viewport: null,  // 避免触发生效 isMobile 字段
  permissions: ['geolocation'],
};
```

### Step 2: 每个 newPage() 后手动设置 viewport

在每个 `session.context.newPage()` 之后添加：

```js
await page.setViewportSize({ width: 1280, height: 720 }).catch(() => {});
```

需要修改的位置（全部共 6 处）：

| 位置行号（约） | 路径 | 说明 |
|---------------|------|------|
| 2610 | POST /tabs 主Tab创建 | 主入口 |
| 2638 | proxy_retry 重试 | 代理轮换时重建 |
| 2810 | recreateTabOnFreshContext | Google搜索拦截重试 |
| 1683 | googleRotateContext | Google特殊处理 |
| 5309 | POST /listItems | 兼容旧API路径 |
| 5336 | listItems proxy_retry | 旧API重试路径 |

### 验证

重启后测试：
```bash
curl -s -X POST http://localhost:9377/tabs \
  -H 'Content-Type: application/json' \
  -d '{"userId":"test","sessionKey":"test1","url":"https://example.com"}' | jq .
```

成功返回 `{"tabId":"...", "url":"https://example.com"}` 即修复完成。

## 注意

- 每次 `npm update @askjo/camofox-browser` 后补丁会被覆盖，需重新打
- 可考虑提 PR 给 camofox-browser 项目修复，或在 camoufox-js 层面处理
