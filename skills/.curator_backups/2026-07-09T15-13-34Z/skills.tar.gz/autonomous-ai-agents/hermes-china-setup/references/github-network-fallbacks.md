# GitHub 网络问题与安装替代方案

从中国大陆访问 GitHub 时，`git clone`、`hermes skills install`、`npx skills add` 都可能因网络不稳定而超时或断连。以下是在 Hermes 场景下处理这些问题的已验证策略。

## 已知失败模式

| 现象 | 报错 | 原因 |
|------|------|------|
| Git clone 卡住后断连 | `fetch-pack: unexpected disconnect while reading sideband packet` | TCP 连接不稳定，数据传输中断 |
| `hermes skills install` 超时 | 60s 无响应 | skills.sh 注册表从国内访问缓慢 |
| `npx skills add` 克隆成功但无结果 | `No valid skills found` | skills CLI 不递归扫描子目录（见 find-skills skill） |
| GitHub API 超时 | `Could not resolve host` 或 connection timeout | DNS/路由问题 |

## 替代方案（按可靠性排序）

### 方案A：Tap + Install（最轻量）

```bash
hermes skills tap add <owner>/<repo>       # 通常能成功
hermes skills install <owner>/<repo>/...   # 可能超时，但值得一试
```

### 方案B：write_file 手动重建（最可靠）

当所有自动安装方式都失败时，直接从 raw.githubusercontent.com 拉取 SKILL.md 内容并写入本地：

```
1. web_extract(url=["https://raw.githubusercontent.com/<owner>/<repo>/main/skills/<name>/SKILL.md"])
2. write_file(path="~/.hermes/skills/<name>/SKILL.md", content=拉取的内容)
3. 确认 YAML frontmatter 包含 name 和 description
4. 确认目录名与 name 匹配
```

**注意：** 这种方式只能拉取 SKILL.md 本身，如果 skill 依赖 `scripts/`、`templates/`、`references/` 等附属文件，需要逐文件拉取。

### 方案C：写一个精简化版本

对于结构复杂的多层 skill（如带 6 个 .mjs 脚本的视频管线），直接写一个更短的精简版 SKILL.md（保持核心方法和命令，去除依赖的脚本），等网络条件好时再补全。

## 何时使用

- **小 skill（纯 SKILL.md，无附属文件）：** 方案B 完全可行
- **大 skill（含 scripts/references）：** 先方案B 拉 SKILL.md，附属文件待网络恢复后补
- **用户急用：** 方案C 精简化版本先跑通核心流程
