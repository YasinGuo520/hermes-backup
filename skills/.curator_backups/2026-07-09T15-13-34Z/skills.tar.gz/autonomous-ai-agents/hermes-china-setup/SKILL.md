---
name: hermes-china-setup
description: "中文网络环境下配置 Hermes Agent 工具（搜索、图像生成、网关管理、浏览器自动化）的指南，包括微信网关特性、区域限制问题和替代方案"
version: 1.6.0
author: Hermes Agent
license: MIT
platforms: [macos, linux, windows]
---

# Hermes 中文环境配置指南

在中文网络环境（中国大陆）下配置 Hermes 的 Web 搜索、图像生成、网关管理等工具时，部分服务存在区域限制或兼容性问题。本技能记录已验证的配置方法和已知坑点。

---

## 微信网关管理

### 重启网关

**在微信里发 `/restart` 无效。** 网关重启必须在电脑终端执行：

```bash
hermes gateway restart    # 重启
hermes gateway stop       # 停止
hermes gateway start      # 启动
hermes gateway status     # 查看状态
```

### 注意

- 微信平台不支持 slash 命令 `restart`、`reset`、`reload-skills` 等会话级控制命令
- 配置变更（工具集、模型、API Key 等）都需要终端重启网关才能生效
- 重启后发送任意消息即会使用新配置

---

## 飞书 (Feishu / Lark) 网关配置

飞书是 Hermes 在中国大陆可用的全功能聊天平台，支持 WebSocket（推荐）和 Webhook 两种连接模式。

### 基础配置

```bash
# .env 中配置以下环境变量（已配好则跳过）
FEISHU_APP_ID=cli_xxx
FEISHU_APP_SECRET=secret_xxx
FEISHU_ENCRYPT_KEY=xxx           # 可选，WebSocket 模式下 SDK 处理签名
FEISHU_VERIFICATION_TOKEN=xxx    # 可选
FEISHU_DOMAIN=feishu             # feishu(中国) 或 lark(国际)
FEISHU_CONNECTION_MODE=websocket # websocket(推荐) 或 webhook
FEISHU_ALLOW_ALL_USERS=true      # 或设置 FEISHU_ALLOWED_USERS 白名单
```

配置后重启网关：
```bash
hermes gateway restart
```

### 权限 Scope 完整清单

**飞书的权限只能在开发者后台手动开启，无法通过 API 或 Hermes 自动配置。** 需要在 [open.feishu.cn](https://open.feishu.cn) → 你的应用 → 权限管理 → 添加权限，然后发布新版本。

#### 🟢 基础必需（5个 — 聊天能用至少需前3个）

| Scope | 用途 | 说明 |
|-------|------|------|
| `im:message` | 接收和读取消息 | ⭐ 收消息必备 |
| `im:message:send_as_bot` | 以机器人身份发消息 | ⭐ 回消息必备 |
| `im:resource` | 访问用户发的图片/文件/音频 | ⭐ 如果没开，用户发图/文件给你，Hermes 收不到 |
| `im:chat` | 访问群聊元数据 | 群聊功能必需 |
| `im:chat:readonly` | 读取群列表和成员 | 群成员过滤等 |

#### 🟡 推荐开启（3个）

| Scope | 用途 |
|-------|------|
| `im:message.reactions:readonly` | 接收表情回应事件 |
| `admin:app.info:readonly` | 自动检测机器人身份（@提及检测） |
| `contact:user.id:readonly` | 解析用户 Open ID 做白名单匹配 |

#### 🔵 高级功能额外权限

| 功能 | 需要添加的 Scope | 需要订阅的事件 |
|------|-----------------|---------------|
| **文档评论自动回复** | `docs:doc:readonly` + `drive:drive:readonly` | `drive.notice.comment_add_v1` |
| **互动卡片点击响应** | 无额外 scope（但需在 Bot 设置中开启「互动卡片」能力） | `card.action.trigger` |
| **会议邀请自动加入** | 视频会议相关权限 | `vc.bot.meeting_invited_v1` |
| **日历功能** | 日历相关权限（需额外申请） | 日历事件 |

### 必备事件订阅

在飞书开发者后台 → 事件订阅中，至少要勾选：
- `im.message.receive_v1` — 收消息（必备）

高级功能还需额外订阅对应事件（见上表）。

### 典型排错

| 问题 | 原因 | 解决 |
|------|------|------|
| 机器人收不到图片/文件 | 没开 `im:resource` 权限 | 在权限管理添加 scope，重新发布 |
| 点击卡片按钮报错 200340 | 互动卡片能力未开启或 Card Request URL 未配置 | 开启互动卡片 + 配 URL（WebSocket 模式无需配 URL） |
| 群聊不响应 | @提及策略或白名单限制 | 检查 `FEISHU_GROUP_POLICY` 和 `FEISHU_ALLOWED_USERS` |
| 机器人身份未自动识别 | 飞书 API 临时不可达 | 手动设 `FEISHU_BOT_OPEN_ID` 和 `FEISHU_BOT_NAME` |
| 配置变更不生效 | 没重启网关 | `hermes gateway restart` |
| 权限添加后仍不可用 | 没发布新版本 | 去版本管理发布新版，企业应用还需管理员审批 |

### 完整环境变量

参考 Hermes 官方文档：https://hermes-agent.nousresearch.com/docs/user-guide/messaging/feishu

### Firecrawl（推荐，国内可用 ✅）

Firecrawl 在国内网络下可用，提供搜索和网页提取双重能力。

```bash
# 1. 在 .env 中添加 API Key
echo 'FIRECRAWL_API_KEY=fc-你的key' >> ~/.hermes/.env

# 2. 配置后端
hermes config set web.backend firecrawl

# 3. 重启网关
hermes gateway restart
```

免费额度：500 credits/月（日常够用）。

### DDGS (DuckDuckGo) — 零配置纯免费

无需 API Key，但**只支持搜索**，不支持网页内容提取。

```bash
hermes config set web.backend ddgs
```

### 其他备选

| 后端 | API Key | 搜索 | 提取 | 国内可用 |
|:---|:---|:---:|:---:|:---:|
| Firecrawl | `FIRECRAWL_API_KEY` | ✅ | ✅ | ✅ |
| DDGS (DuckDuckGo) | 无需 Key | ✅ | ❌ | ✅ |
| SearXNG (自托管) | `SEARXNG_URL` | ✅ | ❌ | ✅ |
| Brave Search | `BRAVE_SEARCH_API_KEY` | ✅ | ❌ | ✅ |
| Tavily | `TAVILY_API_KEY` | ✅ | ✅ | 需测试 |

---

## 图像生成

### 通用配置方式

```bash
# 添加 OpenRouter API Key
echo 'OPENROUTER_API_KEY=sk-or-v1-你的key' >> ~/.hermes/.env

# 配置图像生成后端
hermes config set image_gen.provider openrouter
hermes config set image_gen.model "openai/gpt-5-image-mini"   # 推荐免费模型

# 重启网关生效
hermes gateway restart
```

### OpenRouter 方案（部分受限 ⚠️）

OpenRouter 在国内可用 API 调用，但 **Google Gemini 图像模型全线被区域限制**（返回 403）。

**OpenRouter API Key 验证：**
```bash
# 测试 Key 是否有效
curl -s -H "Authorization: Bearer $OPENROUTER_API_KEY" \
  https://openrouter.ai/api/v1/auth/key

# 列出所有免费的图像生成模型
curl -s -H "Authorization: Bearer $OPENROUTER_API_KEY" \
  https://openrouter.ai/api/v1/models \
  | python3 -c "
import sys,json
data=json.load(sys.stdin)
for m in data.get('data',[]):
    mid = m['id']
    pricing = m.get('pricing',{})
    img_price = pricing.get('image', 0)
    if 'image' in mid.lower():
        free_tag = 'FREE' if float(img_price)==0 else f'\${img_price}/img'
        print(f'{free_tag:>15} | {mid}')
"

**已知限制：**

| 模型 | 状态 | 原因 |
|:---|:---:|:---|
| `google/gemini-3.1-flash-lite-image` | ❌ 403 | 区域限制 |
| `google/gemini-3.1-flash-image` | ❌ 403 | 区域限制 |
| `google/gemini-3-pro-image` | ❌ 403 | 区域限制 |
| `openai/gpt-5-image-mini` | ⚠️ 需手动启用 | 需在 OpenRouter 后台开启 |
| `openai/gpt-5-image` | ⚠️ 需手动启用 | 需在 OpenRouter 后台开启 |
| `black-forest-labs/flux-schnell` | ❌ 模型ID无效 | OpenRouter 接口不支持 |

**解决方案：**
1. 去 [OpenRouter 设置](https://openrouter.ai/settings) 手动启用 OpenAI 图像模型
2. 或注册 [FAL.ai](https://fal.ai/)（免费额度，国内可用 ✅）配置 `FAL_KEY`

**典型报错及含义（用于快速诊断）：**

| 错误信息 | 原因 | 解决 |
|:---------|:-----|:-----|
| `flux-schnell is not a valid model ID` | model ID 必须用完整路径 | 改为 `black-forest-labs/flux-schnell`（但该模型可能仍不可用） |
| `This model is not available in your region` | 区域限制（Google Gemini） | 换用 OpenAI 或 FAL |
| `enable OpenAI image access in your OpenRouter account` | OpenRouter 账户未开放 OpenAI | 去 https://openrouter.ai/settings 手动开启 |
| `FAL_KEY environment variable is not set` | provider 为空时回退到 FAL | 设 `image_gen.provider` 为正确值，或配 FAL_KEY |

### 本地 diffusers 方案（Intel Mac 不推荐 ❌）

在 Intel Mac（Intel Iris Plus 集显，无 Apple Silicon）上尝试本地 Stable Diffusion 会遇到多重问题：

**硬件限制：**
- Intel Iris Plus 集成显卡（共享显存最高 1.5GB），不支持 CUDA/MPS 加速
- CPU-only 推理一张图需数分钟
- 16GB 内存 + <30GB 剩余空间较紧张

**依赖兼容性问题（macOS x86_64 实测）：**
- `torch 2.2.2`（macOS x86_64 可用最新版）与 `diffusers >= 0.30` 存在兼容问题
- 因缺少 `torch.xpu` 模块导致 diffusers 导入即报错；修补后还有连锁兼容问题
- HuggingFace 主站被墙（可用 `hf-mirror.com` 镜像）

**结论：有 GPU 的 Linux 或 Apple Silicon Mac 才值得尝试本地 diffusers。**

### 硅基流动 SiliconFlow（强烈推荐 ✅🏆）

**硅基流动 (SiliconFlow)** 是国内 AI 平台，所有服务在中国大陆可直接访问，无需翻墙。提供免费图像生成 API，兼容 OpenAI API 格式。

**可用图像模型（实测可用）：**
- `Qwen/Qwen-Image` — 通义千问图像模型
- `Kwai-Kolors/Kolors` — 快手开源的图像生成模型
- `Tongyi-MAI/Z-Image-Turbo` — 通义万相快速版
- `baidu/ERNIE-Image-Turbo` — 百度文心图像模型

**配置方法：**
```bash
# 1. 注册 https://siliconflow.cn 获取 API Key

# 2. 设置 API Key（注意！使用 OPENAI_API_KEY 环境变量）
echo 'OPENAI_API_KEY=sk-你的siliconflow-key' >> ~/.hermes/.env

# 3. 配置后端（使用 OpenAI 兼容模式）
hermes config set image_gen.provider openai
hermes config set image_gen.base_url https://api.siliconflow.cn/v1
hermes config set image_gen.model Qwen/Qwen-Image

# 4. 重启网关生效
hermes gateway restart
```

**注意：** 虽然 provider 是 `openai`，但自定义 `base_url` 后请求发到硅基流动，不会走 OpenAI。

### 实际调用方式

**Hermes `image_generate` 工具的限制：** 当 `provider: openai` 且 `base_url` 指向 SiliconFlow 时，Hermes 的 `image_generate` 工具**仍然会尝试 OpenAI 的原生图像端点**（`https://api.openai.com/v1/images/generations`），而不是使用自定义的 `base_url`。实际表现：

```bash
# 即使配置了以下内容：
image_gen:
  provider: openai
  base_url: https://api.siliconflow.cn/v1
  model: Qwen/Qwen-Image
  api_key: sk-xxx
# image_generate 工具仍会报错：模型名不匹配、超时或 403
```

**已验证的可行方案：直接调用 SiliconFlow API**

```python
import urllib.request, json

req = urllib.request.Request(
    'https://api.siliconflow.cn/v1/images/generations',
    data=json.dumps({
        'model': 'Qwen/Qwen-Image',
        'prompt': '你的提示词',
        'n': 1,
        'size': '1024x1024'
    }).encode(),
    headers={
        'Authorization': 'Bearer sk-你的siliconflow-key',
        'Content-Type': 'application/json'
    }
)
resp = json.loads(urllib.request.urlopen(req, timeout=60).read())
url = resp['data'][0]['url']
# 下载图片
urllib.request.urlretrieve(url, '/Users/mac/Desktop/output.png')
```

参数说明：
- `model`: 可用 `Qwen/Qwen-Image`、`Tongyi-MAI/Z-Image-Turbo` 等
- `size`: 支持 `1024x1024`, `1024x768`, `768x1024` 等
- 每次调用消耗账户余额（看图模型定价，通常很便宜）

### FAL.ai 方案（备选 ✅）

FAL.ai 在中国大陆也可直接访问（已实测验证），无需翻墙。

**可达性验证结果：**
```bash
curl -s -o /dev/null -w "HTTP %{http_code} · %{time_total}s" https://fal.ai
# → HTTP 200 · 约5s（网站）
curl -s -o /dev/null -w "HTTP %{http_code} · %{time_total}s" https://api.fal.ai
# → HTTP 200 · 约0.9s（API）
```

**配置方法：**

```bash
# 注册 https://fal.ai/ 获取免费 API Key
echo 'FAL_KEY=你的key' >> ~/.hermes/.env
hermes config set image_gen.provider fal
hermes gateway restart
```

---

## 环境变量管理

所有 API Key 统一放在 `~/.hermes/.env` 中，每行一个：

```bash
DEEPSEEK_API_KEY=sk-xxx
FIRECRAWL_API_KEY=fc-xxx
OPENROUTER_API_KEY=sk-or-v1-xxx
FAL_KEY=fal-xxx
```

修改后需要重启网关才会生效。

---

## 视觉模型（Vision）配置

Hermes 的视觉能力（`vision_analyze` 工具）由**辅助模型**驱动，需要单独配置。默认 `auto` 模式会选择 OpenAI GPT-4o，但在国内不可用。

### 诊断当前配置

```bash
grep -A 5 "auxiliary:" ~/.hermes/config.yaml | grep -A 5 "vision:"
```

如果只有 `vision: - vision` 没有 provider/model，说明未配置。

### 方案 A：OpenRouter（推荐，已有 API Key）

```bash
hermes config set auxiliary.vision.provider openrouter
hermes config set auxiliary.vision.model openai/gpt-4o
hermes gateway restart
```

### 方案 B：SiliconFlow（国内可用✅）

```bash
hermes config set auxiliary.vision.provider openai
hermes config set auxiliary.vision.base_url https://api.siliconflow.cn/v1
hermes config set auxiliary.vision.model Qwen/Qwen-VL-Plus
hermes gateway restart
```

### 验证

发送一张图片测试。如果仍报错 `This model is not available in your region`：
1. 确认 `provider` 不是 `auto`（auto 默认用 OpenAI 直连，被墙）
2. 确认 `model` 名称在目标平台上存在
3. 网关重启后需 `/reset` 新会话才能生效

---

## 浏览器自动化（Camofox 反检测浏览器）

Hermes 内置浏览器工具（`browser_navigate`、`browser_click`、`browser_snapshot` 等）可以使用 Camofox 作为后端——一个基于 Camoufox（Firefox 分支）的反检测浏览器，通过 C++ 级别的指纹伪装绕过 Cloudflare、反爬检测等。

### 国内部署挑战

- Docker Desktop 国内被墙 ❌ → 不能走 Docker 安装
- Camofox 可以通过 npx / npm 直接运行（无需 Docker），只要有 Node.js 即可
- 首次启动会自动下载 Camoufox 二进制 + GeoIP 数据库 + uBlock Origin 插件，国内下载较慢，建议耐心等待
- **坑点：** uBlock Origin 从 addons.mozilla.org 下载（该域名国内被墙），下载会返回空文件，导致启动失败报 `manifest.json is missing`。修复：在 `~/Library/Caches/camoufox/Camoufox.app/Contents/Resources/addons/UBO/` 创建最小 manifest.json：
  ```json
  {
    "manifest_version": 2,
    "name": "uBlock Origin",
    "version": "1.72.0",
    "description": "An efficient blocker",
    "applications": { "gecko": { "id": "uBlock0@raymondhill.net" } }
  }
  ```
  注意 macOS 上 addon 路径在 `.app` 包内部，不是在 cache 根目录。

### 无 Docker 安装（推荐方式）

```bash
# 方式一：npx 直接运行（无需安装，自动缓存）
npx @askjo/camofox-browser
# 首次运行会下载 Camoufox 二进制（~300MB），耗时较长

# 方式二：全局安装（适合长期使用）
npm install -g @askjo/camofox-browser
camofox-browser
```

### 验证服务是否启动

服务启动后监听默认端口 9377，通过 health endpoint 验证：

```bash
curl http://localhost:9377/health
# 返回示例：{"ok":true,"engine":"camoufox","browserRunning":false,...}
# browserRunning: false 是正常的——浏览器按需懒加载，首次请求时自动启动
```

### 已知修复：Camoufox v150 alpha CDP 协议不兼容

Camoufox v150.0.2 (alpha.25) 的 Firefox CDP 协议不识别 Playwright 传递的 `isMobile` 字段，导致 `browser.newContext()` 报错：

```
Protocol error (Browser.setDefaultViewport):
Found property "<root>.viewport.isMobile" - false which is not described in this scheme
```

**修复方法：** 修改 `server.js`（位于全局安装路径下）：

```bash
# 全局安装路径: ~/.local/lib/node_modules/@askjo/camofox-browser/server.js

# 1. 将 contextOptions 中的 viewport 改为 null
#    const contextOptions = {
#      viewport: null,  # 而不是 { width: 1280, height: 720 }
#      permissions: ['geolocation'],
#    };

# 2. 在每个 session.context.newPage() 后补上 viewport 设置
#    const page = await session.context.newPage();
#    await page.setViewportSize({ width: 1280, height: 720 }).catch(() => {});
```

**需要修改的位置（server.js 中约 6 处）：**
- 主 Tab 创建路径（POST /tabs）
- ListItem 路径（POST /listItems）
- Google 搜索重试路径
- 代理轮换重试路径（2处）
- recreateTabOnFreshContext 路径

**注意：** 每次升级 `camofox-browser` 后补丁会被覆盖，需重新打。
```

### ⚠️ 已知坑点：视频/音频页面自动播放声音

**场景：** 用 `browser_navigate` 访问抖音视频页、B站、微博视频等含自动播放 media 的页面时，Camofox 会**自动播放视频/音频**，声音从用户喇叭直接输出。用户会吓一跳。

**原因：** Camoufox 是真实 Firefox 浏览器，抖音/B站等网页版加载后会调用 `HTMLMediaElement.play()` 自动播视频/音频。Camofox 默认无全局静音配置。

**解决方案（三选一，推荐方案A+C结合）：**

**方案A — firefoxUserPrefs 静音（推荐，最干净）：**
直接在 `server.js` 中 `launchOptions()` 返回后注入 Firefox 偏好，在 `options.proxy = normalizePlaywrightProxy(options.proxy);` 之前加：
```js
const options = await launchOptions({...});
// ↓ 新增以下代码
options.firefoxUserPrefs = {
  ...(options.firefoxUserPrefs || {}),
  'media.autoplay.default': 5,        // 5=禁止所有自动播放
  'media.autoplay.blocking_policy': 2, // 严格阻断策略
  'media.autoplay.block-event.enabled': true,
};
// ↑
options.proxy = normalizePlaywrightProxy(options.proxy);
```
**优点：** 浏览器层面阻断，不依赖 JS 注入（JS patch 可能被页面脚本覆盖或绕过），且只加一处（不是6处）。与 CDP viewport 补丁在同一文件维护即可。
**缺点：** 每次升级 camofox-browser 后补丁会被覆盖，需重新打。

**方案B — server.js 加 JS 静音补丁（备选）：**
在 Camofox 的 `server.js` 中，在每个 `session.context.newPage()` 后加静音逻辑（见原版本文档，与 CDP viewport 补丁在同一位置打，共约6处）。



**方案C — 主动提醒用户（兜底）：**
在访问抖音/B站/微博视频等含自动播放的页面**之前**，在回复中主动提醒用户：
> ⚠️ 我要用浏览器打开抖音视频页了，浏览器会自动播放声音，建议你先静音系统音量。

**推荐：方案A + 方案C 双重保障。方案A 打补丁后一劳永逸，方案C 在未打补丁时兜底。**

---

### 配置 Hermes 使用 Camofox

在 `~/.hermes/.env` 中添加：

```bash
CAMOFOX_URL=http://localhost:9377
```

**注意：** `.env` 文件受安全防护机制保护，无法通过终端重定向或编程方式写入。需手动编辑或用 `write_file` 工具写入 `/tmp` 再 `cat` 追加（但终端重定向会被拦截，推荐让用户在终端手动执行 `echo 'CAMOFOX_URL=http://localhost:9377' >> ~/.hermes/.env`）。

```bash
# 用编辑器打开 ~/.hermes/.env，末尾添加：
# Camofox browser server
CAMOFOX_URL=http://localhost:9377
```

当 `CAMOFOX_URL` 设置后，所有 Hermes 浏览器工具自动路由到 Camofox 而不是默认的 agent-browser 或 Browserbase。

### 持久化运行

npx 方式需要保持终端窗口打开。长期使用建议：

```bash
# 全局安装
npm install -g @askjo/camofox-browser

# 后台运行（用 nohup 或 tmux）
nohup camofox-browser > ~/.hermes/camofox.log 2>&1 &
```

### config.yaml 中的可选配置

```yaml
# ~/.hermes/config.yaml
browser:
  camofox:
    managed_persistence: false   # true = 跨会话保持登录/cookie
    adopt_existing_tab: false
    rewrite_loopback_urls: false  # 本地访问容器内服务时启用
    loopback_host_alias: host.docker.internal
```

更多配置详见：https://hermes-agent.nousresearch.com/docs/user-guide/features/browser#camofox-local-mode

### 与 Playwright 的对比

| 特性 | Camofox | Playwright + 反检测 |
|------|---------|-------------------|
| 浏览器引擎 | Firefox（Camoufox） | Chromium |
| 指纹伪装 | C++ 层面，JS 看不到 | JS 层面，易被检测 |
| 安装复杂度 | npm 一行命令 | 需手动配置反检测参数 |
| 与 Hermes 集成 | 自动（设置 env 即可） | 需写独立脚本 |
| 适用场景 | 需要绕过 Cloudflare/反爬的站点 | 通用自动化测试/爬取 |

---

## GitHub 网络问题

GitHub 直连在中国大陆不稳定，git clone、hermes skills install、npx skills add 等操作经常超时或断连。详见：

- **references/github-network-fallbacks.md** — 失败模式诊断表 + 替代方案
- find-skills skill 中也有安装相关的中国网络应对策略

主要应对思路：hermes skills tap add 通常能成功（比 clone 轻量），最后的兜底方案是 write_file 手动从 raw.githubusercontent.com 拉取内容重建 SKILL.md。

---

## 验证配置是否生效

```bash
# 查看已启用的工具集
hermes tools list

# 查看当前 web 后端配置
grep -A2 "web:" ~/.hermes/config.yaml

# 查看当前 image_gen 配置
grep -A3 "image_gen:" ~/.hermes/config.yaml

# 查看当前 auxiliary 配置（视觉等）
grep -A6 "auxiliary:" ~/.hermes/config.yaml

# 检查 .env 中的 API Key 是否加载
grep -v "^#" ~/.hermes/.env | grep -v "^$"
```
