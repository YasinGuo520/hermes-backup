# B站视频真实性调查实战案例 — BV1fVL66SEvC

> 来源：2026-07-07 会话，Yasin 要求调查该视频是否真实/推广，以及背后培训机构

## 视频基本信息

| 字段 | 值 |
|------|------|
| BVID | BV1fVL66SEvC |
| 标题 | AI视频=财富自由？不上班也能实现躺平生活！ |
| UP主 | AI智子财阀君（UID: 385229392） |
| 时长 | 3:38 |
| 发布时间 | 2026-05-19 |
| 分类 | 日常 |

## API 调用方式

B站API在终端环境被墙，但通过 `execute_code` + `web_extract()` 成功获取：

```python
from hermes_tools import web_extract

result = web_extract(urls=["https://api.bilibili.com/x/web-interface/view?bvid=BV1fVL66SEvC"])
# 返回的 content 是 JSON 格式，需解析
```

返回 JSON 中的关键字段：
- `data.stat.view` — 播放量
- `data.stat.like` — 点赞
- `data.stat.coin` — 投币
- `data.stat.favorite` — 收藏
- `data.stat.share` — 分享
- `data.stat.danmaku` — 弹幕
- `data.stat.reply` — 评论数（注：这是主楼评论数，不含楼中楼回复）
- `data.desc` — 视频简介文本
- `data.owner.mid` / `data.owner.name` — UP主信息

## 本案例的推理链

### 红旗信号发现过程

1. **简介为空** → 第一次暴露。真实分享者大概率会写点内容介绍
2. **弹幕仅51条 vs 24.4万播放** → 严重异常。正常万播应有50-200条弹幕
3. **评论仅42条 vs 24.4万播放** → 严重异常。互动率极低
4. **UP主仅3033粉丝** → 与24万播放不匹配。可能投流或刷量
5. **同封面重复发** → 通过空间页发现 "特朗普" 视频和 "50w人看过" 视频各有2个BV号，同一封面不同链接
6. **所有视频标题关键词** → "翻身、躺平、搞钱、副业、邪修、野路子" — 典型的AI焦虑引流话术
7. **全网搜不到课程品牌** → 说明不在公开渠道卖，走私域

### 数据异常速算

```
赞播比: 1762/243774 = 0.72% → 正常偏低
弹幕密度: 51/243774*10000 = 2.09条/万播 → 极低
评论密度: 42/243774*10000 = 1.72条/万播 → 极低
收藏率: 3425/243774 = 1.4% → 正常
```

### 结论：推广/割韭菜内容

可信度评分：1/10。典型的内容农场做号 → 私域转化模式。

## 可复用的调查资源

### B站API端点

| 用途 | URL | 说明 |
|------|-----|------|
| 视频详情 | `https://api.bilibili.com/x/web-interface/view?bvid={BV号}` | 获取视频数据 + UP主信息 |
| UP主投稿 | `https://api.bilibili.com/x/space/arc/search?mid={UID}&pn=1&ps=30` | 投稿列表 |
| UP主信息 | `https://api.bilibili.com/x/space/acc/info?mid={UID}` | 粉丝数、简介、签名 |
| UP主空间 | `https://space.bilibili.com/{UID}` | web_extract 可获取空间页的投稿列表 |
| 视频评论 | `https://api.bilibili.com/x/v2/reply/main?oid={aid}&type=1&mode=3&ps=20` | 需 aid（从视频详情获取） |

### 搜索关键词模板

```
"{UP主名}" 骗子/曝光/避雷/割韭菜
"{UP主名}" 课程/收费/价格
site:xiaohongshu.com "{UP主名}"
site:zhihu.com "{UP主名}"
```

## 注意事项

- B站API走 HTTP（非HTTPS），`web_extract` 可能对某些端点头部校验敏感
- web_extract 抓B站页面时，评论区和动态内容都是 JS 渲染的，抓不到
- 弹幕数据在 PC 端和移动端可能有差异，以 API 为准
- 本案例中 B站推荐流里出现的 "整整600集清华大学" 类视频也是同类型割韭菜内容，注意甄别
