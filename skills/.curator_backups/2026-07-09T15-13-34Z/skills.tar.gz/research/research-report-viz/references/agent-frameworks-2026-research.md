# AI Agent Frameworks 2026 — Research Reference

> Reference file for the `research-report-viz` skill. Captures the data sources and structure used in the July 2026 "AI Agent Frameworks" report.

## Source URLs (all extracted)

| # | URL | Content |
|---|-----|---------|
| 1 | https://www.langchain.com/resources/ai-agent-frameworks | LangChain's own comparison of 7 frameworks (LangChain, CrewAI, MS Agent Framework, LlamaIndex, Google ADK, OpenAI Agents SDK, Mastra) |
| 2 | https://pub.towardsai.net/top-ai-agent-frameworks-in-2026-a-production-ready-comparison-7ba5e39ad56d | Towards AI — 8 frameworks production-tested across healthcare, logistics, fintech |
| 3 | https://alicelabs.ai/en/insights/best-ai-agent-frameworks-2026 | Alice Labs — 7 frameworks ranked (LangGraph #1, Claude Agent SDK #2, CrewAI #3...) |
| 4 | https://www.firecrawl.dev/blog/best-open-source-agent-frameworks | FireCrawl — 10 open-source agent frameworks |
| 5 | https://www.kdnuggets.com/10-agentic-ai-frameworks-you-should-know-in-2026 | KDnuggets — 10 agentic AI frameworks |
| 6 | https://www.datacamp.com/blog/best-ai-agents | DataCamp — best AI agents 2026 |
| 7 | https://resources.anthropic.com/hubfs/2026%20Agentic%20Coding%20Trends%20Report.pdf | Anthropic — 2026 Agentic Coding Trends Report |
| 8 | https://www.gartner.com/en/newsroom/press-releases/2025-08-26-gartner-predicts-40-percent-of-enterprise-apps-will-feature-task-specific-ai-agents-by-2026-up-from-less-than-5-percent-in-2025 | Gartner — 40% of enterprise apps will feature task-specific AI agents by 2026 |

## Framework → Key Links mapping

| Framework | GitHub | Docs | Official |
|-----------|--------|------|----------|
| LangGraph | https://github.com/langchain-ai/langgraph | https://langchain-ai.github.io/langgraph/ | https://www.langchain.com/langgraph |
| Claude Agent SDK | https://github.com/anthropics/claude-agent-sdk-python | https://code.claude.com/docs/en/agent-sdk/overview | — |
| CrewAI | https://github.com/crewaiinc/crewai | https://docs.crewai.com | https://www.crewai.com |
| OpenAI Agents SDK | https://github.com/openai/openai-agents-python | https://openai.github.io/openai-agents-python/ | — |
| Google ADK | https://github.com/google/adk-python | https://adk.dev | https://adk.dev |
| MS Agent Framework | https://github.com/microsoft/agent-framework | https://learn.microsoft.com/en-us/agent-framework/overview/ | — |
| LlamaIndex Workflows | https://github.com/run-llama/llama_index | https://docs.llamaindex.ai | https://www.llamaindex.ai |
| DeerFlow | https://github.com/bytedance/deer-flow | — | — |
| Mastra | https://github.com/mastra-ai/mastra | https://docs.mastra.ai | https://mastra.ai |
| Pydantic AI | https://github.com/pydantic/pydantic-ai | https://ai.pydantic.dev | https://pydantic.ai |

## HTML page structure used

- `/Users/mac/Desktop/agent-showcase/` — output directory
- `AGENT_FRAMEWORKS_2026.md` — markdown report (11,591 bytes)
- `index.html` — HTML showcase page (36,040 bytes)
- Server: `python3 -m http.server 8080` on `127.0.0.1`

## Key CSS/JS components in the HTML page

1. **Particle canvas system** — 80 particles, mouse interaction, connection lines at <120px distance
2. **Grid overlay** — 60px grid with `rgba(0, 240, 255, 0.03)`
3. **Hero** — gradient text (`#00f0ff → #a855f7 → #ec4899`), animated badge dot, stat counters
4. **Framework cards** — glassmorphism, hover lift + glow, rank number overlay, badge tags, link rows
5. **Protocol cards** — simpler card variant for protocol descriptions
6. **Selection guide table** — responsive, bordered, cyan headers
7. **All data driven from JS arrays** — frameworks[], protocols[], guide[], sources[]

## Ordering convention

Rank by general consensus across multiple sources, not just one ranking. In 2026 the consensus top 5 was:
1. LangGraph
2. Claude Agent SDK
3. CrewAI
4. OpenAI Agents SDK
5. Google ADK
