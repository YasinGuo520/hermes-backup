---
name: research-report-viz
description: Research a topic and produce a structured markdown report with a beautiful HTML visualization page — particle background, card layouts, resource links, selection guide, and local hosting.
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [research, report, html, visualization, showcase, documentation]
    related_skills: [claude-design, markdown-to-html, architecture-diagram]
---

# Research Report + HTML Viz

Use this skill when the user asks you to **research a topic and produce a structured report with a visual HTML showcase page**. The deliverable is (a) a well-organised markdown document with all sources and links, and (b) a self-contained tech/cyber-themed HTML page that renders the report as an interactive, browsable showcase.

Typical triggers: "帮我调研一下 XXX，生成展示页面", "research X and create a landing page for it", "make a report on Y with a nice HTML page".

## When NOT to use this

- User just wants a summary or answer (no HTML page needed) → just answer directly
- User wants a full design artifact (landing page, deck) → use `claude-design`
- User wants throwaway UI mockups → use `sketch`
- User wants an Obsidian note / PKB entry → use `personal-knowledge-base`
- User wants a single markdown file without HTML → just write the markdown

## Workflow

### 1. Research phase

Cast a wide net first, then dig deeper into the best sources.

```text
web_search(query="<topic> 2025 2026 overview latest development")
web_extract(urls=["<top 3 results from search>"])
```

**Requirements**:
- Search in both English and Chinese if the topic is relevant to the user's ecosystem
- Extract from at least 2–3 authoritative sources before writing
- Also search for GitHub repos, official sites, and notable blog posts
- If the topic has sub-categories (e.g. individual frameworks), search for each one individually

### 2. Write structured markdown report

Create a detailed `.md` file with:

- **Title**: clear, with emoji indicators
- **Last updated** date
- **Overview section**: context, landscape, key stats
- **Item-by-item deep dives**: each entry gets its own section with:
  - Name + short descriptor
  - ⭐ GitHub stars / popularity indicator
  - Key features and strengths
  - Best-suited scenarios
  - **Resource links block**: official site, GitHub, docs, notable articles — all as clickable markdown links
- **Comparison/selection guide**: table format mapping user needs → recommendations
- **Reference sources list**: all URLs consulted

**User preference (this user)**: structured markdown tables, every item with a one-line justification, data-driven (search first, don't fabricate), no verbose filler. Follow this unless the user specifies otherwise.

### 3. Generate tech-themed HTML page

Create a single self-contained `index.html` with **cyber/tech aesthetic**:

**Visual requirements**:
- Dark theme (`#0a0a0f` / `#111122` base palette)
- Animated particle system (vanilla JS canvas — ~80 particles, mouse interaction, connection lines)
- Grid overlay (`linear-gradient` with subtle cyan lines)
- Neon cyan/purple/pink accent colours (`#00f0ff`, `#a855f7`, `#ec4899`)
- Gradient text for main heading (`linear-gradient cyan → purple → pink`)
- Glassmorphism-style cards with hover glow (`rgba(0,240,255,0.15) box-shadow`)
- Cards that lift on hover with a cyan top border reveal
- JetBrains Mono for code/number accents, Inter for body
- Custom scrollbar (dark track, cyan thumb)
- Responsive (mobile via media queries)

**Structure**:
1. **Hero section** — full-viewport intro with animated badge ("2026 年 7 月 · 最新版" style), gradient headline, subtitle, key stats row
2. **Card grid** — each item as a card with rank number, emoji icon, name, tagline, description, badge tags, and resource links
3. **Supplementary sections** — protocols, comparison tables, reference sources list (as appropriate for the topic)
4. **Footer** — attribution and date

**Technical requirements**:
- All CSS in `<style>` tag
- All JS in `<script>` tag (including particle system inline)
- Zero external dependencies (no CDN, no npm)
- Google Fonts via `<link>` is acceptable (Inter + JetBrains Mono)
- All data should be in JS arrays/objects, rendered via DOM manipulation (don't hand-craft HTML for each card)
- Serve-able directly from any HTTP server (`python3 -m http.server`)

**Particle system code** (reusable):
```javascript
const canvas = document.getElementById('particles-canvas');
const ctx = canvas.getContext('2d');
let particles = [];
let mouseX = 0, mouseY = 0;

function resize() { canvas.width = innerWidth; canvas.height = innerHeight; }
addEventListener('resize', resize); resize();

class Particle {
  constructor() {
    this.x = Math.random() * canvas.width;
    this.y = Math.random() * canvas.height;
    this.size = Math.random() * 2 + 0.5;
    this.speedX = (Math.random() - 0.5) * 0.4;
    this.speedY = (Math.random() - 0.5) * 0.4;
    this.opacity = Math.random() * 0.5 + 0.1;
  }
  update() {
    this.x += this.speedX; this.y += this.speedY;
    if (this.x < 0 || this.x > canvas.width) this.speedX *= -1;
    if (this.y < 0 || this.y > canvas.height) this.speedY *= -1;
    const dx = mouseX - this.x, dy = mouseY - this.y, dist = Math.sqrt(dx*dx+dy*dy);
    if (dist < 120) { this.x -= dx * 0.005; this.y -= dy * 0.005; }
  }
  draw() {
    ctx.beginPath(); ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(0, 240, 255, ${this.opacity})`; ctx.fill();
  }
}

for (let i = 0; i < 80; i++) particles.push(new Particle());

document.addEventListener('mousemove', (e) => { mouseX = e.clientX; mouseY = e.clientY; });

function connect() {
  for (let i = 0; i < particles.length; i++)
    for (let j = i+1; j < particles.length; j++) {
      const dx = particles[i].x - particles[j].x;
      const dy = particles[i].y - particles[j].y;
      const dist = Math.sqrt(dx*dx+dy*dy);
      if (dist < 120) {
        ctx.beginPath(); ctx.moveTo(particles[i].x, particles[i].y);
        ctx.lineTo(particles[j].x, particles[j].y);
        ctx.strokeStyle = `rgba(0, 240, 255, ${0.06 * (1 - dist/120)})`;
        ctx.lineWidth = 0.5; ctx.stroke();
      }
    }
}

function animate() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  particles.forEach(p => { p.update(); p.draw(); }); connect();
  requestAnimationFrame(animate);
}
animate();
```

### 4. Serve and verify

```text
# Start HTTP server in the background
cd /path/to/output/dir && python3 -m http.server 8080 --bind 127.0.0.1

# Verify with curl
curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8080/
```

Confirm it returns `200`, then tell the user the URL.

### 5. Report to user

Tell the user:
- Markdown file path
- HTML file path
- Local URL (http://127.0.0.1:8080)
- Brief content summary

## Pitfalls

- Do NOT skip the research phase and write from memory — always search first, extract, then write. Fabricated data is worse than no data.
- Do NOT use external CDN dependencies for the HTML page except Google Fonts. The page must work offline (except fonts).
- Do NOT use React, Vue, or any framework. Pure HTML/CSS/JS only.
- Do NOT hand-code every card — use JS data arrays + DOM rendering. This keeps the HTML maintainable and the cards consistent.
- Do NOT forget to serve locally — the file on disk is not enough, the user needs to see it in a browser.
- Do NOT use placeholder links — every resource link must be a real URL collected during research.
- If the topic has sub-items (e.g. multiple frameworks, multiple tools), ensure each gets its own card with dedicated links.
- If resources (official sites, GitHub, docs) differ between sub-items, include the correct subset in each card's link section.
- If the user asks for the content to also go into a **Feishu Bitable (多维表格)**, load the `feishu-lark` skill and follow its Bitable API workflow. The bitable creation API requires `bitable:app` permission and has specific format quirks (table names without emoji first, then PATCH to add emoji; record insertion uses field NAMES not IDs).
- Feishu Bitable creation is a complement to the HTML page, not a replacement. Always produce the markdown report and HTML page first, then create the Bitable if requested.

## After completing

If this is the first time this skill was used or a significant topic was covered, offer to save a reference file with the raw research data (extracted pages, search results) under `references/<topic>.md` so future runs can build on prior work.
