# Feishu（飞书）集成配置速查

## 消息平台（已配置、已验证可用）

| 配置项 | 值 | 来源 |
|--------|-----|------|
| FEISHU_APP_ID | `cli_xxx` | 飞书开发者后台 → 凭证与基础信息 |
| FEISHU_APP_SECRET | `***` | 同上 |
| FEISHU_ENCRYPT_KEY | `***` | 事件订阅页面 |
| FEISHU_VERIFICATION_TOKEN | `***` | 事件订阅页面 |
| FEISHU_DOMAIN | `feishu` | 国内版填 feishu，海外版填 lark |
| FEISHU_CONNECTION_MODE | `websocket` | WebSocket 模式（推荐，无需公开 URL） |

### 关键步骤（经常遗漏）

1. **开启机器人能力** — 应用功能 → 机器人 → 启用
2. **订阅消息事件** — 事件订阅 → 添加 `im.message.receive_v1`
3. **添加权限** — 权限管理 → 添加 `im:message` 系列权限
4. **发布版本** — 版本管理与发布 → 创建版本 → 审核 → 发布
5. 发布后去飞书搜索**应用名称**（如"Yasin的智能助手"）→ 发消息测试

### 安全设置

```bash
FEISHU_ALLOW_ALL_USERS=true   # 允许任何人（测试用）
FEISHU_ALLOWED_USERS=ou_xxx   # 白名单模式（生产）
FEISHU_REQUIRE_MENTION=false  # 群聊是否需要 @ 才响应
```

### 验证连接

`grep "feishu" ~/.hermes/logs/gateway.log` 应看到：
```
✓ feishu connected
connected to wss://msg-frontier.feishu.cn/ws/v2?...
```

## 日历 API（⚠️ 限制 + 配置步骤）

飞书日历 API 需要额外的权限范围，**默认不包含在机器人应用中**。需要手动添加：

1. 飞书开发者后台 → 你的应用 → **权限管理**
2. 搜索"日历"
3. 勾选以下权限：
   - `calendar:calendar:readonly` — 读取日历事件
   - `calendar:calendar` — 创建/修改/删除日历事件
4. 点**保存**
5. 左侧 → **版本管理与发布** → 创建新版本（如 `1.0.1`）→ 提交 → 发布

⚠️ 即使权限已添加，也**必须发布新版本**才能生效。

### 日历事件创建（API方式，需上述权限）

```bash
# 先获取 tenant_access_token
APP_SECRET=$(grep FEISHU_APP_SECRET ~/.hermes/.env | cut -d= -f2)
TOKEN=$(curl -s -X POST "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal" \
  -H "Content-Type: application/json" \
  -d "{\"app_id\":\"cli_xxx\",\"app_secret\":\"${APP_SECRET}\"}" | python3 -c "import sys,json;print(json.load(sys.stdin).get('tenant_access_token',''))")

# 创建事件
curl -s -X POST "https://open.feishu.cn/open-apis/calendar/v4/calendars/primary/events" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"summary":"事件标题","start":{"date":"2026-07-06","date_time":"2026-07-06T08:00:00","time_zone":"Asia/Shanghai"},"end":{"date":"2026-07-06","date_time":"2026-07-06T09:00:00","time_zone":"Asia/Shanghai"}}'
```

## 备选方案：Mac系统日历（免权限、免发布）

当飞书日历代权限申请流程太长，或Token权限不足时，可用 macOS 自带日历 + AppleScript：

```bash
# 写入到「个人」日历（带iCloud同步）——会同步到iPhone
osascript -e 'tell application "Calendar" to tell calendar "个人" to make new event with properties {summary:"📖 英语学习", start date:date "2026-07-06 08:00:00", end date:date "2026-07-06 09:00:00"}'

# 注意：每个 osascript 调用只能创建1个事件，需多次调用来批量创建日程
# 要删除已创建的事件：delete every event of calendar "日历" whose start date ≥ "2026-07-06"
```

| 日历名称 | iCloud同步 | 说明 |
|---------|:---------:|------|
| **个人** | ✅ 是 | 推荐使用，自动同步到iPhone |
| **工作** | ✅ 是 | 也可同步 |
| **日历** | ❌ 否 | 本地日历，不会同步到手机 |

**通知控制：**
- iPhone通知：设置 → 通知 → 日历 → 打开
- Mac通知：系统设置 → 通知 → 日历 → 关闭
- 这样写到「个人」日历后，到点只有手机响

## 本地 vs 云端

- **Hermes 跑在本地 Mac** → 电脑休眠即断连，飞书/微信均不可用
- **Hermes 跑在云服务器** → 24小时在线，飞书随时可回复
- **飞书桌面端**仅在电脑开机时收弹窗，手机端不受影响
