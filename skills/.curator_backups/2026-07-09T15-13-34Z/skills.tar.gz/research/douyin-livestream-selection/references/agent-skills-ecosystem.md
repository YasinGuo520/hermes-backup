# Agent Skills 生态 → Hermes Skills 映射表

本会话从两段抖音视频提取并安装了18个新Skill，以下是对照表。

## 视频一：起哥's AI实战 — 16个Skill推荐

安装了：superpowers, frontend-design, code-review, content-risk-detector, skill-creator, agent-reach, markitdown, pptx, playwright-mcp, humanizer-zh

## 视频二：@Juang_42号搭车客 — 4组Skill

| 视频中的Skill | Hermes对应 | 安装状态 |
|--------------|-----------|:-------:|
| SkillCreator | `skill-creator` | ✅ 已装 |
| FindSkills | `find-skills` | ✅ 新装 |
| TDD强制规则 | `test-driven-development` + `superpowers` | ✅ 已有 |
| Garry Tan工具集 | `code-review` + `superpowers` | ✅ 等价 |
| Matt前端工具集 | `frontend-design` + `code-review` | ✅ 等价 |
| Frontend Design | `frontend-design` | ✅ 已有 |
| UX Pro Max | `ux-pro-max` | ✅ 新装 |
| cover-image | `cover-image` | ✅ 新装 |
| xhs-images | `xhs-images` | ✅ 新装 |
| markdown-to-html | `markdown-to-html` | ✅ 新装 |
| translate | `translate` | ✅ 新装 |
| post-to-wechat | `post-to-wechat` | ✅ 新装 |
| post-to-weibo | `post-to-weibo` | ✅ 新装 |
| baoyu-infographic | `baoyu-infographic` | ✅ 已有 |

## 同类Skill整合建议

- `douyin-livestream-ecommerce` (creative) 已被 `douyin-livestream-selection` (research) 合并吸收，应该删除或归档
- `humanizer-zh` (creative) 和 `humanizer` (creative) 功能重叠（中英文去AI味），建议合并
- `code-review` 和已有的 `requesting-code-review` 功能重叠

## 获取来源

- Anthropic官方Skills: https://github.com/anthropics/skills
- awesome-agent-skills: https://github.com/JackyST0/awesome-agent-skills
- baoyu-skills: https://github.com/baoyu-skills (宝玉老师)
- Skills.sh: https://www.skills.sh (Vercel)
- SkillHub(腾讯): https://skillhub.tencent.com/
- ClawHub(OpenClaw): https://clawhub.ai
