# Hermes 辅助视觉模型配置（通过 SiliconFlow 的中国用户）

## 问题现象

`vision_analyze` 返回 `403 - This model is not available in your region`

## 解法

```yaml
# ~/.hermes/config.yaml
auxiliary:
  vision:
    provider: openai
    base_url: https://api.siliconflow.cn/v1
    model: Qwen/Qwen3-VL-32B-Instruct
    timeout: 120
    download_timeout: 30
```

或用 CLI：
```bash
hermes config set auxiliary.vision.provider openai
hermes config set auxiliary.vision.base_url https://api.siliconflow.cn/v1
hermes config set auxiliary.vision.model Qwen/Qwen3-VL-32B-Instruct
```

## 踩过的坑

| 尝试 | 结果 | 原因 |
|------|------|------|
| openai/gpt-4o via OpenRouter | 403 region blocked | OpenAI 在中国被墙 |
| Qwen/Qwen2.5-VL-72B-Instruct via SiliconFlow | 403 Model disabled | 该模型已下线 |
| deepseek-ai/deepseek-vl2 via SiliconFlow | 403 Model disabled | 该模型已下线 |
| **Qwen/Qwen3-VL-32B-Instruct via SiliconFlow** | ✅ 成功 | 当前可用 |

## 需注意

- 辅助模型配置修改后需要**新建会话**（`/reset`）才能生效
- vision_analyze 调用的是 `auxiliary.vision` 配置，**不是**主模型配置
- `base_url` 必须设置为 **SiliconFlow 的完整 v1 地址**（`https://api.siliconflow.cn/v1`）
