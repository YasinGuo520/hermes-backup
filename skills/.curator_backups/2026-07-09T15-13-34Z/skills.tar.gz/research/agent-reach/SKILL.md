---
name: agent-reach
description: 联网信息检索与社交平台内容采集——从抖音/小红书/微博/知乎/B站等平台搜索和提取公开信息，用于市场调研、选品分析和竞品监控。
---

# Agent Reach（联网信息检索）

用于从互联网搜索和提取信息，做市场调研、选品分析、竞品监控。

## 能力范围

| 平台 | 能力 | 方式 | 限制 |
|------|------|------|------|
| 🌐 全网搜索 | 关键词搜索 + 网页内容提取 | web_search + web_extract | — |
| 📺 抖音 | 搜索视频/用户/话题 | web_search定向搜索 | ⚠️ 仅获取文本摘要，无法获取结构化商品/销量数据 |
| 📕 小红书 | 搜索笔记/商品 | web_search定向搜索 | — |
| 📖 知乎 | 搜索问答/文章 | web_search定向搜索 | — |
| 📦 GitHub | 仓库信息/README | web_search + web_extract | — |
| 📡 RSS | 订阅源内容 | web_extract | — |

## 限制说明

- **web_search + web_extract 无法处理 JS 渲染的页面**（如抖音商城、百应工作台等）。
- 抖音反爬极强：无登录时直接访问搜索页/商品页会跳验证码。
- **需要结构化商品数据的场景**（销量、价格、佣金率），建议使用 Playwright（skill: playwright-mcp）配合已登录的浏览器 session 来采集。
- 第三方数据平台（聚推客联盟、有米有数、蝉妈妈、飞瓜）的 API 均需注册/付费，无法通过简单 HTTP 请求免费获取。

## 使用场景

- 竞品分析：搜"XX品牌 抖音 销量"了解对手
- 选品调研：搜"抖音 热销 收纳 2026"看趋势
- 口碑监控：搜"XX产品 测评 小红书"看用户评价
- 货源查找：搜"1688 XX品类 代发"找供应商
- 内容真实性鉴别：判断B站/小红书视频是真实分享还是推广引流/割韭菜内容（详见 ⭐ `references/bilibili-video-investigation.md`）

## 进阶：登录后数据采集（computer_use）

对于需要登录的 JS 重型平台（如抖音百应工作台、蝉妈妈、飞瓜数据），可用 **computer_use** 操作用户已登录的浏览器直接提取数据：

1. 用户先在自己浏览器登录目标平台
2. 用 `computer_use(action='capture', app='Safari', mode='som')` 获取页面元素
3. 通过 SOM 索引点击导航到目标页面
4. 用 vision 或 SOM 解析提取结构化数据

详见 ⭐ `references/douyin-baiying-scraping.md` （抖音百应工作台精选联盟数据采集完整流程）

### 注意事项

- Playwright 不继承 Safari/Chrome 的登录 cookie，需要用户手动扫码
- 自定义 UI 控件（下拉箭头、筛选框等）可能不支持 AXPress，需改用 coordinate 点击
- 所有生成的 Excel 文件统一输出到 `~/Desktop/hermes/`
