---
name: a-share-market-data
description: A股（中国A股）实时行情、板块排名、个股查询 — 基于新浪财经免费API，零依赖，无需VPN。
version: 1.0.0
author: Hermes Agent
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [A-shares, China, stocks, finance, 股票, A股]
    category: finance
    related_skills: [stocks, a-share-stock-selection-methodology]
---

# A股市场数据 (A-Share Market Data)

从中国大陆获取A股实时行情、板块排名、个股数据。**无需API密钥、无需安装包、不会翻墙**。
数据源：新浪财经免费接口（`hq.sinajs.cn`）。

## 何时使用

- 用户问 A股 实时股价（"寒武纪多少钱""查一下有研硅"）
- 用户想看 **板块涨幅排名**（"今天什么板块涨"）
- 用户在中国，Yahoo Finance 无法访问
- 需要快速获取A股个股的开盘价、最高价、成交量等实时数据
- 需要获取 **行业板块** 或 **概念板块** 的涨跌幅排名

## 前提条件

- `curl` 可用（macOS/Linux 自带）
- Python 3.8+ 即可（解析脚本只用 stdlib）

## 代码格式

| 交易所 | 前缀 | 示例 |
|--------|------|------|
| 上海主板 (`6`开头) | `sh` | `sh600519` 贵州茅台 |
| 科创板 (`688`开头) | `sh` | `sh688256` 寒武纪 |
| 深圳主板 (`00`开头) | `sz` | `sz002185` 华天科技 |
| 创业板 (`300`开头) | `sz` | `sz300043` 星辉娱乐 |

## 快速查询（curl）

```bash
# 单只股票
curl -s -H "Referer: https://finance.sina.com.cn" \
  "https://hq.sinajs.cn/list=sh688256"

# 多只股票（逗号分隔）
curl -s -H "Referer: https://finance.sina.com.cn" \
  "https://hq.sinajs.cn/list=sh688432,sz002185,sz002558,sz300043,sh688256,sh603019"
```

**⚠️ Referer 头必须加**，否则返回 HTTP 403 Forbidden。

如果返回乱码（GBK编码），加 `iconv` 转 UTF-8：
```bash
curl -s -H "Referer: https://finance.sina.com.cn" \
  "https://hq.sinajs.cn/list=sh688256" | iconv -f GBK -t UTF-8
```

## 响应格式解析

新浪返回 JavaScript 变量赋值：

```
var hq_str_sh688432="有研硅,38.980,38.450,46.140,46.140,38.130,46.140,0.000,76565979,3389040404.000,...,2026-07-07,15:20:34";
```

引号内逗号分隔的字段：

| 索引 | 字段 | 含义 |
|:----:|:----:|:----:|
| 0 | 名称 | 股票中文名 |
| 1 | 开盘价 | 今日开盘 |
| 2 | 昨收价 | 昨日收盘 |
| 3 | 当前价 | **最新成交价** |
| 4 | 最高价 | 今日最高 |
| 5 | 最低价 | 今日最低 |
| 6 | 竞买价 | 买一价 |
| 7 | 竞卖价 | 卖一价 |
| 8 | 成交量 | 手数 |
| 9 | 成交额 | 元 |
| ... | 买五~卖五 | 盘口明细 |
| -2 | 日期 | YYYY-MM-DD |
| -1 | 时间 | HH:MM:SS |

### 涨跌幅计算

```python
change_pct = (current_price - prev_close) / prev_close * 100
```

**科创板/创业板**：涨跌幅 20%（涨停=昨收×1.2，跌停=昨收×0.8）
**主板**：涨跌幅 10%（涨停=昨收×1.1，跌停=昨收×0.9）

## 使用脚本

技能自带 `scripts/sina_ashare.py` 脚本，封装了 curl + 解析逻辑：

```bash
# 批量查询个股
python3 ~/.hermes/skills/finance/a-share-market-data/scripts/sina_ashare.py quote sh688432 sz002185 sz002558

# 获取行业板块涨幅排名
python3 ~/.hermes/skills/finance/a-share-market-data/scripts/sina_ashare.py sectors

# 获取概念板块涨幅排名
python3 ~/.hermes/skills/finance/a-share-market-data/scripts/sina_ashare.py concept
```

## K线（历史行情）数据

A股K线数据有两种可靠来源：

### 来源 A：新浪财经 K线 API（推荐 — 最稳定）

无需 Referer 头，纯 JSON 格式，`urllib`/`requests`/`curl` 均正常工作。

```bash
# 日线（scale=240），最多约 300 条
curl -s "https://money.finance.sina.com.cn/quotes_service/api/json_v2.php/CN_MarketData.getKLineData?symbol=sz002050&scale=240&ma=no&datalen=100"
# 60分钟线（scale=60）
curl -s "https://money.finance.sina.com.cn/quotes_service/api/json_v2.php/CN_MarketData.getKLineData?symbol=sh688256&scale=60&ma=no&datalen=40"
```

**参数说明：** `symbol`=sh/sz+代码, `scale`=240(日线)/60(60分钟), `datalen`=条数

**响应格式：** JSON数组，每项`{day, open, high, low, close, volume}`，价格字段是字符串

**注意事项：** 无Referer要求，无频率限制，不含成交额/换手率

### 来源 B：东方财富历史K线 API（含换手率和成交额）

```bash
# 日线（klt=101），secid规则：1.xxx=上证, 0.xxx=深证
curl -s "https://push2his.eastmoney.com/api/qt/stock/kline/get?secid=0.002050&fields1=f1,f2,f3&fields2=f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61&klt=101&fqt=1&end=20500101&lmt=100"
```

**参数说明：** `secid`=1.上证代码/0.深证代码, `klt`=101日线/102周线/60=60分钟, `lmt`=条数

**响应格式：** 逗号分隔：`日期,开盘,收盘,最高,最低,成交量(手),成交额(元),振幅(%),涨跌幅(%),涨跌额,换手率(%)`

**注意事项：** 偶有Python urllib SSL握手失败（curl通常正常），需清理JSONP括号包裹

### 多周期分析推荐

| 场景 | 周期 | 数据量 | 用途 |
|------|------|--------|------|
| 日线趋势 | 日线 | 60-100条 | 主趋势、MA/RSI/MACD |
| 短线入场 | 60分钟 | 40条 | 入场时机、支撑压力 |
| 大方向 | 周线 | 30条 | 周线方向判断 |
| 量价分析 | 日线 | 100条 | 量比、放量启动 |

> **推荐组合：** 新浪拉日线和60分钟线（稳定），东方财富拉周线（含换手率）。

## 板块数据

新浪不直接提供板块排行接口。要获取板块涨跌幅排名，用以下替代方案：

### 方案 A：东方财富网页抓取

```bash
curl -s "https://push2.eastmoney.com/api/qt/clist/get?cb=&pn=1&pz=20&po=1&np=1&fields=f12,f14,f3,f62,f184,f66&fs=m:90+t:2" | python3 -c "import sys,json; d=json.loads(sys.stdin.read()); [print(f\"{i['f14']}: {i['f3']}%\") for i in d.get('data',{}).get('diff',[])]"
```

参数说明：
- `m:90+t:2` = 行业板块, `m:90+t:3` = 概念板块
- `f3` = 涨跌幅, `f14` = 板块名
- `po=1` = 降序（涨幅从高到低）

### 方案 B：Web搜索

当API不可用时，用 `web_search` 搜索当日热点板块：
> 搜索词: `A股 今日 板块涨幅排名`
> 来源: 东方财富、证券时报、同花顺

## 完整的 A股量化分析流程

当用户要求"量化分析A股板块""推荐股票""选股分析"时，**必须先加载 `a-share-stock-selection-methodology` skill**（选股方法论），本skill只负责数据获取。

执行顺序：
1. **加载选股方法论** → `skill_view(name='a-share-stock-selection-methodology')`
2. **获取板块排名** — 东方财富API或web_search
3. **确认热点板块** — 结合资金流向、涨停家数，验证板块资金是否连续3日流入
4. **板块内选股** — 选中龙头+弹性标的各一只，需同时验证多周期（日线+60分+周线）
5. **获取实时股价** — Sina Finance API验证
6. **获取成交量/技术指标** — 计算量比、MACD、布林带（使用execute_code + pandas_ta）
7. **交付结构化报告** — Markdown表格，包含：板块名、涨跌幅、推荐个股、RSI、MACD信号、量比信息、目标价位、止损位、逻辑、风险提示

## 风险提示

- Sina Finance 接口是非官方的，可能在不通知的情况下变更
- 东方财富推送接口同样非官方
- 所有数据**延迟约 3-5 秒**（非Level-2行情）
- 仅供研究参考，**不构成投资建议**
- 国内市场有涨停板制度，追涨需谨慎

## 技能文件结构

```
finance/a-share-market-data/
├── SKILL.md                       # 本文件 — 综合使用指南
├── scripts/
│   └── sina_ashare.py             # A股行情查询 + 板块排名脚本
├── references/
    ├── sina-finance-api.md        # 新浪财经API格式详细文档（含字段表）
    ├── eastmoney-sector-api.md    # 东方财富板块排名API文档（含curl示例）
    └── eastmoney-kline-api.md     # 东方财富历史K线API文档（含参数表、Python示例）
```

## Pitfalls

- curl 必须加 `Referer: https://finance.sina.com.cn` 头，否则403
- GBK编码问题：用 `iconv -f GBK -t UTF-8` 或 Python 的 `.decode('gbk')`
- **subprocess.run获取新浪行情时不要用text=True**：会强制utf-8解码失败，正确做法是 `capture_output=True` 不加text参数，再 `.decode('gbk')`
- 新浪单次请求最多约 100 只股票，过多会被截断
- 板块排名用东方财富推送接口（`push2.eastmoney.com`），新浪不提供
- **东方财富板块排名API偶发空响应**：非硬依赖，可从个股评分聚类反推热点板块
- **Python urllib对东方财富K线API偶发SSL握手失败**（curl正常），建议脚本中用curl替代
- 科创板/创业板与主板的涨跌幅限制不同（20% vs 10%），计算涨幅时注意
- 新浪K线不含成交额和换手率，需要这些字段时用东方财富K线API

## 验证

### curl 直查
```bash
curl -s -H "Referer: https://finance.sina.com.cn" \
  "https://hq.sinajs.cn/list=sh688256" | iconv -f GBK -t UTF-8
```

### 脚本查询
```bash
python3 ~/.hermes/skills/finance/a-share-market-data/scripts/sina_ashare.py quote sh688432
```

### 板块排名
```bash
python3 ~/.hermes/skills/finance/a-share-market-data/scripts/sina_ashare.py sectors --top 10
```
