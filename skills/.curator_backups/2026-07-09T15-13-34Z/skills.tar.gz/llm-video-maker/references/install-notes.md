# LLM Video Maker 安装说明

## 来源

上游项目：https://github.com/GoldLegendW80/llm-video-maker (MIT license)
版本：v1.0.0 (2026-06-17)
Stars: 5

## 这个 skill 是什么

一个基于 HyperFrames 引擎的 AI 视频生成管线。与 Hermes 现有的 `ai-video-production`（Python+moviepy）路线不同，这个是用 HTML/GSAP 写合成层，通过 Chrome headless 渲染成 MP4——类似 Remotion 的思路。

**两个 sub-skill：**
- `make-video` — brief → 完整 MP4（含配音、字幕、音乐、图标、b-roll）
- `edit-video` — 章节级编辑已生成的视频

## 已补全状态

所有上游文件已通过 jsDelivr CDN 下载完成并放入 skill 目录：

| 文件 | 大小 | 位置 |
|------|------|------|
| `schema.json` | 9.4KB | `../schema.json` |
| `validate-brief.mjs` | 9.8KB | `../scripts/` |
| `plan-scenes.mjs` | 8.3KB | `../scripts/` |
| `fetch-assets.mjs` | 17.7KB | `../scripts/` |
| `analyze-codebase.mjs` | 7.6KB | `../scripts/` |
| `capture-demo.mjs` | 6.4KB | `../scripts/` |
| `normalize-transcript.mjs` | 6.5KB | `../scripts/` |

补全日期：2026-07-09 | 方式：jsDelivr CDN 直链 | 状态：完整

## 使用条件

- `Node >= 22` 需自行安装
- `FFmpeg` 需自行安装
- `Google Chrome` 正常安装
- Kokoro TTS 模型（~80MB）首次运行自动下载

## 安装完整版

```bash
# 等网络条件好时，用 npx 安装完整版
npx skills add GoldLegendW80/llm-video-maker --yes --global

# 或手动克隆
git clone https://github.com/GoldLegendW80/llm-video-maker.git /tmp/lvm
cp -r /tmp/lvm/skills/make-video ~/.hermes/skills/make-video
cp -r /tmp/lvm/skills/edit-video ~/.hermes/skills/edit-video
rm -rf /tmp/lvm
```
