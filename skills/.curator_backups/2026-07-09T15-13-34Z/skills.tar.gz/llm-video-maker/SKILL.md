---
name: llm-video-maker
description: Turn a prompt or brief into a fully rendered MP4 video using HyperFrames engine. AI video generation with voiceover (TTS), word-synced captions, music, icons, brand logos, stock photos, and b-roll. TikTok/Reels/Shorts (9:16), YouTube (16:9), square (1:1). HTML/GSAP deterministic render, Remotion-style. Companion skill: edit-video for chapter-scoped edits.
metadata:
  version: 1.0.0
  source: https://github.com/GoldLegendW80/llm-video-maker
---

# /llm-video-maker — brief → rendered video (Hermes adaptation)

You are the pipeline orchestrator. This skill wraps the [HyperFrames](https://www.npmjs.com/package/hyperframes) engine: the agent writes HTML/GSAP compositions, the engine renders them to MP4 via Chrome headless. Every stage writes its artifact into the project directory so the run is resumable.

This skill works best for: TikTok/Reels/Shorts, YouTube intros, startup hero loops, product promos, data explainers with animated charts, square social posts.

## Prerequisites (one-time setup on this machine)

All dependencies are already installed:

| Component | Status | Version |
|-----------|--------|---------|
| Node.js | ✅ | v22.23.1 |
| FFmpeg | ✅ | 8.1.2 |
| Chrome | ✅ | 143 |
| HyperFrames engine | ✅ | 0.7.45 |
| Kokoro TTS (local) | ✅ | kokoro-onnx 0.5.0 |
| Soundfile | ✅ | 0.14.0 |

**Before using this skill**, ensure Kokoro venv is in PATH:
```bash
export PATH="/Users/mac/.video-maker/runtime/python/bin:\$PATH"
```
Add that line to `~/.zshrc` to make it permanent.

## Quick Start

```bash
# Install HyperFrames engine in a project
mkdir -p ~/Desktop/hermes/video-maker && cd ~/Desktop/hermes/video-maker
npm init -y
npm i -D hyperframes@0.6.91
mkdir -p briefs projects
```

```bash
# Install companion authoring skills (once)
npx hyperframes@0.6.91 skills
```

## Usage

Provide a brief (JSON or inline description) then:

```
/make-video "30s TikTok promo for a productivity app — funny, high energy, Chinese voiceover"
```

Required brief fields: `id`, `platform` (tiktok/reels/shorts/youtube/square), `story`, `source`.

## Pipeline Stages

1. **PREFLIGHT** — check Node, FFmpeg, Chrome via `npx hyperframes doctor`
2. **INGEST** — research topic / analyze codebase / interpret script → write `facts.json`
3. **DESIGN** — palette, typography, motion personality → write `design.md`
4. **STORYBOARD** — scene plan → write `storyboard.json`
5. **ASSETS** — fetch icons, images, b-roll, music → write `assets/`
6. **COMPOSE** — write HTML/GSAP composition → `index.html`
7. **VALIDATE** — lint, WCAG AA contrast, vision pass (max 3 iterations)
8. **RENDER** — `npx hyperframes render projects/<id>` → MP4
9. **QA + REPORT** — ffprobe, frame extraction, sync check → `report.md`

## AI Voiceover

Local Kokoro TTS (offline, ~80MB model download once):
```bash
uv venv ~/.video-maker/runtime/python
uv pip install --python ~/.video-maker/runtime/python/bin/python kokoro-onnx soundfile
```
Model auto-downloaded to `~/.cache/hyperframes/tts/models/kokoro-v1.0.onnx`

Or supply your own recording + timestamped transcript (transcript-locked mode).

## Optional API Keys (free tiers)

| Key | Unlocks |
|-----|---------|
| `PEXELS_API_KEY` / `PIXABAY_API_KEY` | stock photos + video b-roll |
| `GIPHY_API_KEY` / `TENOR_API_KEY` | reaction gifs |
| `FREESOUND_API_KEY` | CC0 sound effects |
| `OPENAI_API_KEY` + `IMAGE_GEN=openai` | AI image generation |

## Companion Skill

`edit-video` — chapter-scoped edits of finished videos without re-rendering everything. Trigger: `/edit-video <project-id> <chapter-id> "make the intro punchier"`

## Bundled Scripts

This skill ships with the full upstream pipeline scripts locally under `$SKILL_DIR/scripts/`:

| Script | Size | Purpose |
|--------|------|---------|
| `validate-brief.mjs` | 9.8KB | Validate brief format against schema |
| `plan-scenes.mjs` | 8.3KB | Scene planning and transcript coverage |
| `fetch-assets.mjs` | 17.7KB | Fetch icons, stock photos, b-roll, music |
| `analyze-codebase.mjs` | 7.6KB | Analyze codebase to extract facts |
| `capture-demo.mjs` | 6.4KB | Playwright screen capture for app demos |
| `normalize-transcript.mjs` | 6.5KB | Normalize timestamped transcripts |
| `schema.json` | 3.4KB | Brief input validation schema |

Scripts are invoked via `node "$SKILL_DIR/scripts/<name>.mjs"` — each is a self-contained Node.js CLI with `--help` output.

## Notes

- No network at render time; all assets vendored locally
- Facts on screen must trace to `facts.json` — no invented stats
- Deterministic, validated render — runs are resumable
- Output lands in `projects/<id>/`
