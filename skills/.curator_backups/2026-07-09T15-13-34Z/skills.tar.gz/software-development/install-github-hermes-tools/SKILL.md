---
name: install-github-hermes-tools
description: Install third-party tools from GitHub that ship with their own Hermes skills and plugins (e.g. quant-trade, community projects). Covers cloning, venv setup, symlink integration, and verification.
tags: [github, skills, plugins, setup, integration]
related_skills: [find-skills, skill-creator]
---

# Install Third-Party GitHub Hermes Tools

When a user finds a GitHub project that extends Hermes with its own skills (`skills/` dir) and plugins (`plugins/` dir), use this skill to install and integrate it properly.

## Trigger Conditions

Use this skill when:
- User found a GitHub repo that contains `skills/` and/or `plugins/` directories under a Hermes-agent-compatible project
- User wants to install a third-party quant/automation/utility tool that isn't on the official skill registry
- A community project's README mentions Hermes Agent integration but doesn't provide a `hermes skills install` command

## Installation Steps

### 1. Clone the Repository (preferred)

```bash
cd ~/Desktop  # or a suitable workspace directory
git clone https://github.com/<user>/<repo>.git
```

**China mirror fallback** (when direct GitHub clone times out):
```bash
# Try these mirrors in order:
git clone https://gitclone.com/github.com/<user>/<repo>.git
git clone https://ghproxy.net/https://github.com/<user>/<repo>.git
```

**jsDelivr CDN fallback** (when even mirrors fail — pull individual files instead of full clone):
```bash
# Use jsDelivr CDN to fetch individual raw files (fast in China)
BASE="https://cdn.jsdelivr.net/gh/<user>/<repo>@main"

# Pull SKILL.md files from skills/ subdirectories
curl -sL "$BASE/skills/<skill-name>/SKILL.md" -o ~/.hermes/skills/<skill-name>/SKILL.md

# Pull additional scripts/files
curl -sL "$BASE/skills/<skill-name>/scripts/<script>.mjs" -o ~/.hermes/skills/<skill-name>/scripts/<script>.mjs

# Verify
hermes skills list | grep <skill-name>
```
This avoids the full Git clone entirely — jsDelivr CDN is hosted on Chinese mainland CDN nodes and doesn't suffer from GFW throttling.

### 2. Set Up Python Virtual Environment

Most projects require Python >= 3.12. Prefer the user's Python 3.13:

```bash
cd ~/Desktop/<repo>
# Find the right Python
which python3.13  # Homebrew, prefer this
/usr/local/bin/python3.13 -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

For China users, pip may need extra time — set timeout accordingly (300s).

### 4. Link Skills to Hermes

If the repo has a `skills/` directory with individual skill subdirectories:

```bash
cd ~/Desktop/<repo>
for skill in skills/*/; do
    name=$(basename "$skill")
    ln -sfn "$(pwd)/skills/$name" ~/.hermes/skills/<prefix>-$name
done
```

Use a unique prefix (e.g. `quant-`) to avoid name collisions with existing skills.

### 5. Link Plugins to Hermes

If the repo has a `plugins/` directory:

```bash
cd ~/Desktop/<repo>
ln -sfn "$(pwd)/plugins/<plugin_name>" ~/.hermes/plugins/<plugin_name>
```

### 6. Verify Installation

Test that the core tools import cleanly:

```bash
cd ~/Desktop/<repo>
source venv/bin/activate
python -c "
import sys; sys.path.insert(0, '.')
from plugins.<plugin_name> import *
print('✅ Import OK')
"
```

Then test with a live data call (if applicable) to confirm real functionality.

### 7. Handle Environment Variables

- Check if the project needs a `.env` file
- If API keys are needed, inherit from the user's existing Hermes config where possible (e.g. `OPENAI_API_KEY` for LLM features)
- For optional features (exchange API keys, notification channels), note these as configurable but not required for basic operation

### 8. Install Official Companion Skills

Some projects complement official Hermes skills. Install companion skills non-interactively:

```bash
yes | hermes skills install official/finance/stocks
```

## Pitfalls & Troubleshooting

- **PEP 668 protection** - System Python (brew) prevents `pip install` outside venv. Always use a venv.
- **Python version mismatch** - Check the project's `python_requires` in `pyproject.toml` or `requirements.txt`. Fall back to 3.13 if 3.12+ required.
- **AKShare / Yahoo Finance API drift** - AKS省e 和 yfinance 等免费数据源的API可能变更，导致特定函数失效。验证时先测基础功能（stock_quote等），再看高级功能（估值、研报）。
- **Symlink vs copy** - Use `ln -sfn` (soft link) so updates to the git repo automatically reflect in Hermes. The original project may have gitignored these paths otherwise.
- **GitHub connectivity in China** - If direct clone fails, try `gitclone.com` or `ghproxy.net` mirrors with extended timeout (120s+). For individual files, jsDelivr CDN (`cdn.jsdelivr.net`) is more reliable — no full clone needed.
- **`npx skills add` fails on nested SKILL.md** - `npx skills add <owner>/<repo>` reports "No valid skills found" if SKILL.md is under `skills/<name>/` subdirectory (skills CLI only checks repo root). Use `hermes skills tap add` + manual install, or use jsDelivr CDN to pull files directly.
- **`yes | hermes skills install`** — The install command prompts for confirmation interactively. Pipe through `yes` for non-interactive automation.
- **Memory limit** — Add install record to memory for future reference, but keep it compact (project path, venv path, key features enabled).

## Reference

For official skill installations, use `hermes skills install official/<category>/<name>` — no special setup needed.
For single-skill installs from community registries, use the `find-skills` skill.
